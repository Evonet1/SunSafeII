
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2023-07-25    chris.moller@evonet.com -->
	<title>Save Infrastructure JSON file</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2.7/other2json.php       -->
	<meta charset="utf-8">

	<style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: lightblue;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }
 

	</style>

	
</head>

<body >

    <?php


    error_reporting(-1);
    ini_set("display_errors", 1);

    /* This generates a JSON file for a complex component
     * inputs are:
            mfr
            model
            wpk
            ocv
            scc
              iname[]
              ivoltage[]
              ifrequency[]
              icurrent[]
              iunits[]
            battV
            battA
            ctlChem[]
            battCap
            battEff
              oname[]
              ovoltage[]
              ofrequency[]
              ocurrent[]
              ounits[]

    */

    define("VERSION" , "2.7");

    require("json_utilities.php");


    $fileName = $_GET["fileName"].".json";

    $mfr = $_GET["mfr"];
    $model = $_GET["model"];


    echo ("<h1>Sunsafe JSON file creation for $mfr $model</h1>");



    $data = array();
    $energy = array();

    $data['$schema'] = "sunsafe".VERSION.".json";
    $data["brand"] = $mfr;
    $data["model"] = $model;
    $ports = array();

    //Deal with solar input
    if (key_exists("ocv", $_GET)) {
        $ocv = checkKey("ocv");
        $scc = checkKey("scc");
        $port = array();
        $port["name"] = ["Solar in"];
        $port["function"] = ["offers", "solarIn"];
        $port["mustConnect"] = false;
        $port["maxConn"] = -1; //any number of solar panels
        $port["voltage"] = ["requires", 0, floatval($ocv)];
        $port["current"] = ["requires", -floatval($scc), 0];
        $port["frequency"] = ["requires", "0Hz"];
        $port["protocol"] = ["offers", "solarIn"];
        array_push($ports, $port);
    }

    //deal with any number of general inputs
    if (key_exists("iname",$_GET)) {
        $inames = $_GET["iname"];
        for ($iindex = 0; $iindex < sizeof($inames); $iindex++) {
            $iname = $inames[$iindex];
            $ivoltage = $_GET["ivoltage"][$iindex];
            $ifrequency = $_GET["ifrequency"][$iindex];
            $icurrent = $_GET["icurrent"][$iindex];
            $iunits = $_GET["iunits"][$iindex];
            $iprotocol = $_GET["iprotocol"][$iindex];

            $port = array();
            $port["name"] = $iname;
            $port["function"] = ["requires", "powerOut"];
            $port["mustConnect"] = false;
            $port["maxConn"] = 1;  //only one supply nneded
            $port["voltage"] = getCurrentRange($ivoltage,true);
            $port["current"] = getCurrentRange($icurrent,false);
            $f1 = explode(",", $ifrequency);
            print_r($f1);
            foreach ($f1 as &$f0) {
                if (($f0 == "DC") or ($f0 == "dc")) {
                    $f0 = "0Hz";
                } else {
                    $f0 = strval($f0) . "Hz";
                }
            } 
            $f2 = array_prepend($f1, "requires");
            $port["frequency"] = $f2;
            $port["protocol"] = ["requires", $iprotocol];
            array_push($ports, $port);
        }

    }

    //Deal with an exposed battery port
    if (key_exists("battV", $_GET)) {
        $battV = checkKey("battV");
        $battA = checkKey("battA");
        $port = array();
        $port["name"] = ["Battery port"];
        $port["function"] = ["offers", "BatteryPort"];
        $port["mustConnect"] = true;
        $port["maxConn"] = -1; //any number of cells
        $battV1 = explode(",", $battV); //several different discrete nominal voltages may be supported
        $battV2 = array_prepend($battV1, "offers");
        $port["voltage"] = $battV2;
        $port["current"] = ["requires", 0, floatval($icurrent)];
        $pcol = $_GET["ctlChem"];
        $pcol1 = array_prepend($pcol, "offers");
        $port["protocol"] = $pcol1;
        array_push($ports, $port);
    }

    //Deal with energy
    if (key_exists("capacity", $_GET)) {
        $capacity = $_GET["capacity"];
        $battEff = $_GET["battEff"];
        $energy["capacity"] = $capacity;
        $energy["battEff"] = $battEff;
    }
    $loss = $_GET["loss"];
    $efficiency = $_GET["efficiency"];
    $energy["loss"] = $loss;
    $energy["efficiency"] = $efficiency;




    $data["ports"] = $ports;

    $data["energy"] = $energy;




    $fileName = $_GET["fileName"].".json";

    $fileText = json_encode($data, JSON_PRETTY_PRINT);

//    echo ($fileText);

    $myfile = fopen("data/".$fileName,"w");
    fwrite($myfile,$fileText);
    fclose($myfile);



    echo ("<p>File $fileName successfully created</p>");



    ?>

    <form action="phpqrcode/p2.php" method="GET" name="inputData" id="inputData">
        <input type="hidden" id="file" name="file" value="<?=$fileName?>" />

        <input name="submit" type="submit" value="View the created JSON data..." />

    </form>

</body>
</html>

