
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2023-07-25    chris.moller@evonet.com -->
	<title>Save appliance JSON file</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2/app2json.php       -->
	<meta charset="utf-8">

	<style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: lightblue;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }
 

	</style>

	
</head>

<body >

    <?php

    //we expect from appdatacollect.php to get:
    //mfr,model,apType,voltage,frequency,current,Runits,averagePower,Aunits,protocol, filename


    error_reporting(-1);
    ini_set("display_errors",1);

    define("VERSION", "2.7");

    require("json_utilities.php");


    //fetch all the GET parameters
    $mfr = checkKey("mfr");
    $model = checkKey("model");
    $apType = checkKey("apType");
    $voltage = checkKey("voltage");
    $frequency = checkKey("frequency");
    $current = checkKey("current");
    $Runits = checkKey("Runits");
    $averagePower = checkKey("averagePower");
    $Aunits = checkKey("Aunits");
    $protocol = checkKey("protocol");
    $fileName = $_GET["fileName"] . ".json";


    echo ("<h1>Sunsafe JSON file creation for appliance $mfr $model</h1>");

   //fix parameters as necessary
    if ($voltage == "") {
        die("Voltage must be specified");
    }

    $voltage = array_map("floatval", explode(",", $voltage));   //voltage will always be an array of numbers
    if (sizeof($voltage) == 1) {
        $nomVolts = floatval($voltage[0]);   //a required voltage should always be a range
        $minVolts = dp2($nomVolts * 0.95);  //so assume at least a +-5% tolerance
        $maxVolts = dp2($nomVolts * 1.05);
        $voltage[0] = $minVolts;
        $voltage[1] = $maxVolts;
    }

    if ($frequency == "") {
        $frequency = ["0Hz"];
    } else {
        $frequency = explode(",", $frequency);
        foreach ($frequency as &$f1) {
            if (($f1 == "DC") or ($f1 == "dc")) {
                $f1 = "0Hz";
            } else {
                $f1 = $f1 . "Hz";
            }
        }
    }

    if ($Runits == "Watts") {   //force to Amps
        $current = dp2($current / $voltage[0]);
    }

    if ($Aunits == "Amps") {    //force to watts
        $averagePower = dp2($averagePower * end($voltage));
    }


    $data = array();
    $data['$schema'] = "sunsafe" . VERSION . ".json";
    $data["brand"] = $mfr;
    $data["model"] = $model;
    $data["apType"] = $apType;

    $ports = array();
    $energy = array();

    $port = array();
    $port["name"] = ["Power in"];
    $port["function"] = ["requires","powerOut"];
    $port["mustConnect"] = true;
    $port["maxConn"] = 1;


    $voltage = array_prepend($voltage, "requires");
    $port["voltage"] = $voltage;

    $frequency = array_prepend($frequency, "requires");
    $port["frequency"] = $frequency;
    $port["current"] = ["requires",0,$current];
    $port["protocol"] = $protocol;
    array_push($ports, $port);
    $data["ports"] = $ports;


    $energy["averagePower"] = -floatval($averagePower);
    $data["energy"] = $energy;

    $fileText = json_encode($data,JSON_PRETTY_PRINT);

    $myfile = fopen("data/".$fileName,"w");
    fwrite($myfile,$fileText);
    fclose($myfile);

    echo ("<p>File $fileName successfully created</p>");


    ?>

    <form action="phpqrcode/p2.php" method="GET" name="inputData" id="inputData">
        <input type="hidden" id="file" name="file" value="<?=$fileName?>" />

        <input name="submit" type="submit" value="View the created JSON data..." />

    </form>

</body>
</html>

