
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2023-07-19    chris.moller@evonet.com -->
	<title>Sunsafe Infrastructure Data Capture</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2.7/datacollect.php       -->
	<meta charset="utf-8">

    <link href="dual-listbox.css" rel="stylesheet">

	<style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: white;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }

	</style>

	
</head>

<body >

    
    <?php

    error_reporting(-1);
    ini_set("display_errors",1);


 //   require "../json_utilities.php";

    $mfr = $_GET["mfr"];
    $model = $_GET["model"];

    ?>
<h1>Sunsafe 2.7 Infrastructure Data Capture - <?=$mfr." ".$model?></h1>

<p>Enter the requested data.  This may be found on the product's rating plate, in the User<br/>
    Manual, or on the packaging.  If this information is missing, just leave the default value, but note<br/>
    that this could give a very misleading result.</p>

<form action="generateJson.php" method="GET" name="inputData" id="inputData">

    <input type="hidden" name="mfr" id="mfr" value =" <?=$mfr?>" />
    <input type="hidden" name="model" id="model" value="<?=$model?>" />

    <?php

    if (sizeof($_GET) == 4)  {      //brand,model,outputs,submit
        echo("The specified kit is empty!");
        exit(1);    
    }

    $solarPanel = (key_exists("solarPanel",$_GET));
    $mainsIn = (key_exists("mainsIn",$_GET));
    $solarIn = (key_exists("solarIn",$_GET));
    $charger = (key_exists("charger",$_GET));
    $battery = (key_exists("battery",$_GET));
    $outputs = $_GET["outputs"];

    ?>
    <input type="hidden" name="outputs" id="outputs" value ="<?=$outputs?>" />
    <?php

    //if a single item, the issue of the ability to connect won't arise
    if ((sizeof($_GET) > 5) and $solarPanel and !$solarIn) { 
        echo("A solar panel can only connect to a solar controller!");
        exit(1);
    }
    if ((sizeof($_GET) > 4) and $charger and !$mainsIn and !$solarIn) {
        echo("A battery charger must have a power source!");
        exit(1);
    }

    if ($solarIn and !$charger) {
        echo ("<h2>WARNING - The output will not be continous!</h2>");
    }

    if ($solarPanel) {
        ?>
        <!-- We need this for energy calculations, regardless of what else is in the system -->
        <h3>Solar Panel</h3>
        <p>Watts-peak (Wpk) for the solar panel: <input type="text" size="5" id="wpk" name="wpk" , value="30" /> watts</p>
        <?php
        if (!$solarIn) {
            ?>
            <!-- If the solar panel and controller are not both part of a kit (and therefore presumably matched), we will need the electrical characteristics of the panel-->
            <p>Maximum open-circuit voltage of the solar panel: <input type="text" size="5" id="ocv" name="ocv", value="80"/> volts</p>
            <p>Maximum short-circuit current of the solar panel: <input type="text" size="5" id="scc" name="scc", value="5"/> amps</p>
            <?php
        }
    }

    if ($solarIn or $mainsIn) {
        echo("<h3>Inputs</h3>");
    }
    if ($solarIn) {
       if (!$solarPanel) {
            ?>
            <!-- If the solar panel and solarIn are not both part of a kit (and therefore presumably matched), we will need the electrical limitations of the controller's solar input-->
            <p>Maximum permitted voltage of the solar input to the controller: <input type="text" size="5" id="maxocv" name="maxocv" , value="80" /> volts</p>
            <p>Maximum solar panel input current to the controller: <input type="text" size="5" id="maxscc" name="maxscc" , value="5" /> amps</p>
           <?php
       }
    }
    if ($mainsIn) {
        ?>
        <!-- If the controller has a mains input, we need to know how much power we can take -->
        <p>Mains input voltage: <input type="text" size="5" id="mainsV" name="mainsV" , value="230" /> volts<br/>
                (Optionally, enter minimum and maximum mains voltages separated by commas)</p>
        <p>Supply frequency: <input type="text" size="5" id="mainsF" name="mainsF" value="50" /> Hz</p>
        <p>Maximum mains input current: <input type="text" size="5" id="mainsA" name="mainsA" , value="" /> amps</p>
        <?php
           
    }

    if ($charger and !$battery) {
        ?>
        <!-- If the charger does not have an integral battery, we will need the electrical characteristics of the charger's battery port -->
        <h3>Charge controller</h3>
        <p>Supported nominal battery voltage(s) - separate multiple values with commas: <input type="text" size="5" id="ctlBattVolts" name="ctlBattVolts" , value="12" /> volts</p>
        <p>Maximum charging current: <input type="text" size="5" id="ctlBattAmps" name="ctlBattAmps" , value="5" /> amps</p>
        <p>Supported battery chemistries (use Ctrl  to select multiple): 
            <select  name="ctlChem[]" id="ctlChem[]" multiple>
                <option selected>Lead-acid VRLA</option>
                <option>Wet lead-acid</option>
                <option>Lead-acid AGM</option>
                <option>Lithium Iron Phosphate (LiFePO4)</option>
                <option>Lithium Iron Phosphate (LiFePO4) with CANbus BMS</option>
                <option>Lithium–nickel–manganese–cobalt oxides (NMC)</option>
                <option>Li-ion</option>
                <option>Nickel-Cadmium (NiCd)</option>
            </select></p>
        <?php

    }
    if ($outputs > 0) {
        echo ("<h3>Outputs</h3>");
        for($outputsC = 1;$outputsC <= $outputs;$outputsC++) {
            $outputsCount = strval($outputsC);
            ?>
        
            <h3>Power Output <?=$outputsCount?></h3>
            <p>Nominal Output voltage: <input type="text" size="15" id="nomVolts<?=$outputsCount?>" name="nomVolts<?=$outputsCount?>" , value="" /> volts</p>
            <p>Rated Output power/current: <input type="text" size="5" id="nomAmps<?=$outputsCount?>" name="nomAmps<?=$outputsCount?>" , value="" /> 
                <select  name="Dunits<?=$outputsCount?>" id="Dunits<?=$outputsCount?>">
                    <option selected >Amps</option>
                    <option>Watts</option>
                </select></p>
            <p>Power protocol: <input type="text" size="15" id="protocol<?=$outputsCount?>" name="protocol<?=$outputsCount?>" , value="(none)" /></p>
            <?php
        }
    }
 

   
    if ($battery) {
        echo("<h3>Battery</h3>");
        if ((!$solarIn) and (!$mainsIn)) {
            ?>
            <!-- If the battery isn't integrated in the controller, we will need the electrical characteristics of the battery -->
            <p>Battery voltage: <input type="text" size="10" id="battVolts" name="battVolts" , value="12" /> volts<br/>
                (Optionally, enter minimum and maximum battery voltages separated by commas)</p>
            <p>Battery chemistry: <select  name="battChem">
                    <option>Lead-acid VRLA</option>
                    <option>Wet lead-acid</option>
                    <option>Lead-acid AGM</option>
                    <option>Lithium Iron Phosphate (LiFePO4)</option>
                    <option>Lithium–nickel–manganese–cobalt oxides (NMC)</option>
                    <option>Li-ion</option>
                    <option>Nickel-Cadmium (NiCd)</option>
                </select>
            </p>
            <p>BMS signalling protocol: <input type="text" size="15" id="battBMS" name="battBMS" , value="(none)" /></p>
            <?php
        }
        ?>
        <!-- We need this for energy calculations, regardless of what else is in the system -->
        <p>Battery storage capacity: <input type="text" size="5" id="battAh" name="battAh" , value="5" /> Amp-hours</p>
        <p>Battery round-trip efficiency: <input type="text" size="5" id="battEff" name="battEff" , value="85" /> %</p>
        <?php
    }

    if ($inverter) {
        echo("<h3>Inverter</h3");
        ?>
        <!-- The inverter will always have an exposed output, so we will need its capabilities-->
        <p>Nominal AC output voltage: <input type="text" size="5" id="ACvout" name="ACvout" , value="230" /> Volts</p>
        <p>AC output frequency: <input type="text" size="5" id="ACfreq" name="ACfreq" , value="50" /> Hz</p>
        <p>Nominal AC output power: <input type="text" size="5" id="ACpwr" name="ACpwr" , value="150" /> Watts</p>
        <p>Short-term AC peak output power: <input type="text" size="5" id="ACPkpwr" name="ACPkpwr" , value="250" /> Watts</p>
        <p>No-load power consumption: <input type="text" size="5" id="idlePwr" name="idlePwr" , value="10" /> Watts</p>
        <p>Full load efficiency: <input type="text" size="5" id="FLeff" name="FLeff" , value="85" /> %</p>
        <?php
        if (!$solarIn) {
            ?>
            <!-- If the inverter isn't integrated in the controller, we will need its input requirements -->
            <p>Inverter input voltage: <input type="text" size="5" id="invInVolts" name="invInVolts" , value="12" /> volts</p>
                (Optionally, enter minimum and maximum supply voltages separated by commas)</p>
            <p>(Input current rating will be determined from the output power and the efficiency)</p>
            <?php
        }

    }
?>

    <h3>Energy performance</h3>
    
    <?php
    if (sizeof($_GET) > 6) {   //This needs to exclude solar panels and batteries (and of course appliances)
        echo('<p>Power continuously drawn by this kit, even with no load: <input type="text" size="5" name="loss" id="loss" value="0"/> watts</p>');
    }
    if ($charger or $inverter or $mainsIn or $solarIn) {
    //This needs to be cleverer - actually a map of efficiencies between pairs of ports
        echo('<p>Throughput efficiency between input and output ports: <input type="text" size="5" name="eff" id="eff" value="95"/> %</p>');
    }
    ?>


     <h3>Filename</h3>
     <p><input id="fileName" name="fileName" value="" />.json</p>


     <p><input name="submit" type="submit" value="Create JSON file..." /></p>


</form>




</body>
</html>

