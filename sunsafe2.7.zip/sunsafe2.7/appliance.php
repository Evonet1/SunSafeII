
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2023-07-25    chris.moller@evonet.com -->
	<title>Sunsafe Appliance Data Capture</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2/index6.php       -->
	<meta charset="utf-8">

	<style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: lightblue;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }

	</style>

	
</head>

<body >

<h1>Sunsafe Appliance Data Capture</h1>

<p>On this page, select the appliance for which you want a JSON<br/>
    compatibility file, and then press Next.</p>

<?php
    $appdata = file_get_contents("appliances.json");
    $app_data = json_decode($appdata,true);
    if (is_null($app_data)) {
        echo "appliances.json is not a valid JSON file".PHP_EOL;
        exit(1);
    }

    $supplies = $app_data["supplies"];
    $appliances = $app_data["appliances"];

?>

<p>Select the type of appliance and supply, and press Next</p>
<form action="appdatacollect.php" method="GET" name="inputData" id="inputData">
    <select class="select1" name="apType" id="apType">

        <?php


    foreach ($appliances as $appliance) {
        $appName = $appliance["apType"];
        if ($appName != "solarPanel") {
            echo ('    <option value="' . $appName . '">' . $appName . '</option>' . PHP_EOL);
        }
    }
    echo ('</select>');

        ?>
    <p>&nbsp;</p>

    <select class="select2" name="supplyType" id="supplyType">
        <option value="ACsupply">AC mains</option>
        <option value="LVDCsupply">Low-volltage DC</option>
        <option value="USBout">USB</option>
    </select>

    <p>&nbsp;</p>

    <input name="submit" type="submit" value="Next..." />


</form>




</body>
</html>

