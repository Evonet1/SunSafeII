
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2023-07-25    chris.moller@evonet.com -->
	<title>Sunsafe Inverter or power converter Data Capture</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2.7/inverterdatacollect.php       -->
	<meta charset="utf-8">

	<style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: lightblue;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }
 

	</style>

	
</head>

<body >

<?php


/* This has to deliver to inverter2json.php:
 *     mfr, model, vin, vout,wout,wpk,fout, loss, eff
 *     ie volts for input, volts, rated watts, peak watts, frequency for output, no load power loss and throughput efficiency 

*/


?>


<form action="inverter2json.php" method="GET" name="inputData" id="inputData">

    <table>
        <tr>
            <td colspan="2" align="center">
                <b>General</b>
            </td>
        </tr>
        <tr>
            <td align="right">Product manufacturer/brand</td>
            <td>
                <input id="mfr" name="mfr" value="" />
            </td><td>&nbsp;</td>
        </tr>
        <tr>
            <td align="right">Product/model number</td>
            <td>
                <input id="model" name="model" value="" />
            </td><td>&nbsp;</td>
        </tr>
        <tr>
            <td colspan="2" align="center">
                <b>Electrical characteristics</b>
            </td>
        </tr>
        <tr>
            <td align="right">Nomminal input voltage (or voltage limits separated by commas):</td>
            <td><input id="vin" name="vin" value="12" />
            </td><td>Volts</td>
        </tr>
        <tr>
            <td align="right">Nominal output voltage:</td>
            <td>
                <input id="vout" name="vout" value="230" />
            </td><td>Volts</td>
        </tr>        <tr>
            <td align="right">Rated continuous output power:</td>
            <td><input id="wout" name="wout" value="0" />
            </td><td>Watts</td>
        </tr>
        <tr>
            <td align="right">Short-term peak output power:</td>
            <td><input id="wpk" name="wpk" value="0" />
            </td><td>Watts</td>
        </tr>
        <tr>
            <td align="right">Output frequency</td><td>
                <input id="fout" name="fout" value="50" />
            </td><td>Hz</td>
        </tr>
        <tr>
            <td align="right">No-load current</td><td>
                <input id="loss" name="loss" value="0" />
            </td><td>Amps</td>
        </tr>
        <tr>
            <td align="right">Transfer efficiency</td><td>
                <input id="eff" name="eff" value="95" />
            </td><td>%</td>
        </tr>
        <tr>
            <td colspan="2" align="center">
                <b>Save</b>
            </td>
        </tr>       <tr>
            <td align="right">Product data file name</td><td>
                <input id="fileName" name="fileName" value="" />
            </td><td>.json</td>
        </tr>   
    </table>


        <input name="submit" type="submit" value="Create JSON file..." />


</form>




</body>
</html>

