
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2023-07-25    chris.moller@evonet.com -->
	<title>Save Infrastructure JSON file</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2.7/inverter2json.php       -->
	<meta charset="utf-8">

	<style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: lightblue;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }
 

	</style>

	
</head>

<body >

    <?php


    error_reporting(-1);
    ini_set("display_errors", 1);

    /* This generates a JSON file for a standalone inverter
     *     inputs are: mfr, model, vin, vout,wout,wpk,fout, loss, eff
     *     ie volts for input, volts, rated watts, peak watts, frequency for output, no load power loss and throughput efficiency

    */

    define("VERSION" , "2.7");

    require("json_utilities.php");


    $fileName = $_GET["fileName"].".json";

    $mfr = $_GET["mfr"];
    $model = $_GET["model"];
    $vin = getOptions($_GET["vin"]);    //allow alternatives separated by commas
    $vout = floatval($_GET["vout"]);
    $wout = floatval($_GET["wout"]);
    $wpk = floatval($_GET["wpk"]);
    $fout = floatval($_GET["fout"]);
    $loss = floatval($_GET["loss"]);
    $eff = floatval($_GET["eff"]);


    echo ("<h1>Sunsafe JSON file creation for $mfr $model</h1>");

    $energy = array();

    //calculate input current
    $inputCurrent = dp2(($wpk * 100 / $eff) / $vin[0]);


    $data = array();
    $data['$schema'] = "sunsafe".VERSION.".json";
    $data["brand"] = $mfr;
    $data["model"] = $model;

    $energy["perHour"] = $loss;
    $energy["efficiency"] = $eff;

    $data["ports"] = array();

    $port = array();
    $port["name"] = "DC in";
    $port["function"] = ["requires", "PowerOut"];
    $vin = array_prepend($vin, "requires");;
    $port["voltage"] = $vin;
    $port["current"] = ["requires",$inputCurrent];
    array_push($data["ports"], $port);

    $port2 = array();
    $port2["name"] = "AC out";
    $port2["function"] = ["offers", "PowerOut",0,-1];
    $port2["voltage"] = ["offers",$vout];
    $port2["current"] = ["offers",dp2($wout/$vout)];

    $fout = explode(',', $fout);
    foreach ($fout as &$fout1) {
        $fout1 = $fout1 . "Hz";
    }
    $fout = array_prepend($fout, "offers");
    $port2["frequency"] = $fout;
    array_push($data["ports"], $port2);


    $data["energy"] = $energy;




    $fileName = $_GET["fileName"].".json";

    $fileText = json_encode($data, JSON_PRETTY_PRINT);

//    echo ($fileText);

    $myfile = fopen("data/".$fileName,"w");
    fwrite($myfile,$fileText);
    fclose($myfile);



    echo ("<p>File $fileName successfully created</p>");



    ?>

    <form action="phpqrcode/p2.php" method="GET" name="inputData" id="inputData">
        <input type="hidden" id="file" name="file" value="<?=$fileName?>" />

        <input name="submit" type="submit" value="View the created JSON data..." />

    </form>

</body>
</html>

