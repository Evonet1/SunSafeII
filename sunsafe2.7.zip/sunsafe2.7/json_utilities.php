<?php

//The following routines are applicable to ANY JSON files (not just Sunsafe)

function indent_json ($json_data) {
    //With any valid JSON file, add newlines and indentation
    //Returns null if the data is not valid JSON
    //This is the opposite of compact_json()
	if (!is_string($json_data)) {
		return "JSON is not a string";
	}
    $php_obj = json_decode($json_data);
	if (is_null($php_obj)) {
		return "Illegal JSON format";
	}
    $json_obj = json_encode($php_obj, JSON_PRETTY_PRINT);
    return $json_obj;
}

function display_json($json_data) {
	// Prepare JSON file for a web page
	$js1 = indent_json($json_data);
	return ('<pre>'.$js1.'</pre>');
}

function compact_json ($json_data) {
    /*With any valid JSON file:
        Escape any control chars in strings to their unicode equivalents (so we can remove double-quotes)
        Remove all whitespace
        The result is still valid JSON - just smaller */

        //The following characters are allowed in a JSON string, but also form part of
        //  the essential JSON syntax
        $syntax_chars = array("[","]","{","}",":",",");
        //These are replaced with their \u00xx equivalents
        $js1 = str_replace('\\"','\\u0022',$json_data);   //deal with any escaped " in a string
        //Note that this could cause an issue with a string ending \\" - this isn't easily fixed
        $elements = explode('"',$js1);
        $result = "";
        $string_flag = false;   //first will always be control char in valid JSON
        foreach ($elements as $element) {
            $this_element = $element;
            if ($string_flag) {     //we are in a string

                foreach ($syntax_chars as $syntax_char) {      //replace with safe equivalent
                    $unicode = "\\u00".bin2hex($syntax_char);
                    $this_element = str_replace($syntax_char,$unicode,$this_element);
                }
                $string_flag = false;
            } else {    //this is a series of JSON syntax chars, so leave intact
                $this_element = preg_replace('/\s/','',$this_element);  //remove any whitespace in syntax
                $string_flag = true;
            }
            $result .= ('"'.$this_element);   //build result string, putting back doubleqotes.
        }
        $result = ltrim($result,'"');
        //At this point, we have escaped anything that needed escaping, and removed all whitespace not in values

        return ($result);
}


/******************************************************************************/

// The following routines are specific to SunSafe JSON files

/******************************************************************************/


//The first string in the compressed file is the name and version of the format,
//  eg "Sunsafe2.2".  This will reference a JSON schema, eg ../Sunsafe2.2.json
//  and also a dictionary file ../Sunsafe2.2.csv


/******************************************************************************/

function compress_json ($json_string) {
    /* This turns JSON into a shorter ASCII string, without the JSON punctuation.  It only works
    correctly if doublequotes and other control characters in string literals have been replaced
    with escape codes. Whilst this is NOT valid JSON, valid JSON can be easily recovered from it. */

 // set global variable $schema to the value of the $schema value;


    $result = compact_json($json_string);  //escape any control characters, remove whitespace
    //ensure all numeric values are signed (NB positive signed values are not valid JSON)
    $pattern = '/:([0-9])/';
    $result = preg_replace($pattern,':+$1',$result);

    //lastly, remove all double-quotes and nulls
    $result = str_replace('"','',$result);
    $result = str_replace('null','',$result);

    $result = preg_replace('/\$\$:(\S+).json/', "$1", $result); //strip the $$: and .json from the schema
//  strip {}
//  if the file now starts $$:..\/  -remove it, then remove the first occurrence of .json, to just leave the name of the schema


    return ($result);
}



/******************************************************************************/

function restore_json ($qr_string) {

    //  Undo the compression done by compress_json():
    //output is valid JSON

    //restore the $$: and .json around the schema
    $ex = explode(",", $qr_string);
    $ex[0] = str_replace("{","{\$$:../",$ex[0]).".json";
    $js1 = implode(",",$ex);

    //restore all the double-quotes
    $js2 = trim(preg_replace("/[\\[\\]\\{\\}:,]+/",'"$0"',$js1),'"');
    //Any sequence of syntax chars has " added before and after.
    //Trim removes the initial and final "
    $js3 = preg_replace ("/:(\\s*[,\\]\\}])/",':null'.'$1',$js2);   //restore null values
    $js4 = preg_replace ("/([\\[\\{:]),/",'$1'.'null,',$js3);

    // Remove the double-quotes just added around numeric values
    $pattern = '/"([+\-]?[0-9]+(\.[0-9]+)?(E[+\-]?[0-9]+)?)"/';
    $js5 = preg_replace($pattern,'$1', $js4);
    $js6 = str_replace(":+",":",$js5);  //remove the added '+'

 //   $js7 = '{"$schema":"'.$schema.'",'.substr($js6,1);   //prepend the schema

    return $js6;
}


/******************************************************************************/


function load_dict() {

    //Load CSV dictionary
 //This comprises (short_form),(long_form),(control)
 //Control may be 0,1 or 2. 0=only parameter names,1= only parameter values,2=either
 $row = 0;
 $dict_file = __DIR__."/dict.csv";
 $dict_table = [];
 $dict_handle = fopen($dict_file, "r") or die("Dictionary $dict_file not found!");
 while (($data = fgetcsv($dict_handle, 1000, ",")) !== FALSE) {
     $num = count($data);
     if ($num == 2) {
         array_push($dict_table,$data);
     } else {
         die("Unrecognised dictionary format in $dict_file!");
     }
 }
 fclose($dict_handle);
 //report("Dict loaded (".count($dict_table)." records)",3);
 return($dict_table);

}

function shortlong($short_text) {
 // Use a dictionary stored in dict.csv to expand parameter names and values into something more readable

 $dict_table = load_dict();
 $result = $short_text;
 foreach ($dict_table as $dict_entry) {
     $result = str_replace('"' . $dict_entry[0] . '"', '"' . $dict_entry[1] . '"', $result);
     $result = str_replace('"' . $dict_entry[0] . '_', '"' . $dict_entry[1] . '_', $result);
    }
 return($result);
}


function longshort($long_text) {
 // Use a dictionary stored in dict.csv to compress parameter names/values into 2 chars

 $dict_table = load_dict();

 //remove the schema
 //$result = preg_replace('/(\s)*"\$schema"[^,]+,[\n\r]*/',"",$long_text);
    $result = $long_text;

    foreach ($dict_table as $dict_entry) {
     $result = str_replace('"'.$dict_entry[1].'"','"'.$dict_entry[0].'"',$result);
     $result = str_replace('"'.$dict_entry[1].'_','"'.$dict_entry[0].'_',$result);
 }

 return($result);

}

function dp2($number) {
    //reduce a floating point number to 2dp, but keep as a number
    $float = round($number * 100);
    return ($float / 100);
}



function array_prepend($array,$value)  {
    //prepend a value to an array, return the result
    $temp = array_reverse($array);
    array_push($temp, $value);
    return(array_reverse($temp));
}

function getOptions($optionList) {
    //Take an input which may be a number, or several separated by commas
    //Turn them into a floating point array
    $options = explode(',', $optionList);
    $out = array_map('floatval', $options);
    return ($out);
}

function getCurrentRange($optionList,$widen) {
    //take a single value or two, and provide min/max values in an array
    //if widen=true, a single value becomes a +-5% range,
    //otherwise the missing value is zero
    $values = getOptions($optionList);
    switch (sizeof($values)) {
        case 0:
            die("Missing options to getCurentRange");
        case 1:
            if ($widen) {
                return (["requires", dp2($values[0] * 0.95), dp2($values[0] * 1.05)]);
            } else {
                if ($values[0] < 0) {
                    return (["requires", $values[0], 0]);
                }
                return (["requires", 0, $values[0]]);
            }
        case 2:
            return(["requires",$values[0],$values[1]]);
        default:
            die("getCurrentRange - too many values!");
    }
}

function checkKey($parameter) {
    //Look for a parameter in a URL, if found, return it, else return blank
    if (key_exists($parameter,$_GET)) {
        return ($_GET[$parameter]);
    } else {
        return ("");
    }
}

function tf($val)  {    //Print True or False
    if ($val) {
        echo ("True<br/>");
    } else {
        echo ("False<br/>");
    }
    return;
}



?>
