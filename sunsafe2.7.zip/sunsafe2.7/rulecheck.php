<?php


// Check compatibility based on the criteria in rules.docx

error_reporting(-1);
ini_set("display_errors", 1);

require("json_utilities.php");


function prelimCheck($parm1,$parm2,$parmType) {
    //Find out if we have enough information to do a compatibility check.
    //If we don't, we can't fail compatibility on this basis - though we might like to!)

    global $debug;

    if ($debug) echo ("<br/>Dealing with $parmType<br/>");
    if (!key_exists($parmType,$parm1) or (!key_exists($parmType,$parm2))) {
        if ($parmType == "voltage") {
            $result = false; //voltage is mandatory
        } else {
            $result = true; //lack of other information doesn't cause failure
        }
    } else {
        $newParm1 = $parm1[$parmType];
        $newParm2 = $parm2[$parmType];
        $result = ruleCheck($newParm1, $newParm2, $parmType);
    }
    if ($debug) {
        echo ("Result($parmType)=");
        tf($result);
    }
    return ($result);
}

function ruleCheck($p1, $p2, $parmType) {
    //p1,p2 are the values for two components - one will be 'offers' and the other 'requires'
    //parmType is either 'voltage', 'current', 'power' or some text parameter

    global $debug;

    if (!is_array($p1) or !is_array($p2)) {
        die("Wrong format for parameters for ruleCheck!");
    }
    if ((sizeof($p1) < 2) or (sizeof($p2) < 2)) {
        die("Parameter(s) missing values!");
    }
    if (!is_string($p1[0]) or !is_string($p2[0])) {
        die("No string p[0] for ruleCheck!");
    }
    $pp = $p1[0] . $p2[0];
    switch($pp) {
        case 'requiresrequires':
            return(false);  //requirements unmet
        case 'offersoffers':
            return(true);   //if there are no requirements (is this right??)
        case "offersrequires":
            $offers = $p1;
            $requires = $p2;
            break;
        case "requiresoffers":
            $offers = $p2;
            $requires = $p1;
            break;
        default:
            die("No requires or offers");
    }

//    echo ("Passes basic parameter requirements<br/>");

    if (is_string($offers[1]) and is_string($requires[1])) {    //we must match string values
        if ($debug)
            echo ($offers[1] . " and " . $requires[1]);
        for ($requiresIndex = 1; $requiresIndex < sizeof($requires); $requiresIndex++) {  //try all alternative solutions to requirement
            if (is_string($requires[$requiresIndex])) { //ignore the possible last two numeric values
                if ($offers[1] == $requires[$requiresIndex]) { //we have a solution
                    return (true); //we need to take account of the numbers, too
                }
            }
        }
        return (false);     //strings don't match - what's offered isn't what's required

    } else {    //we are dealing with a numeric range - voltage, current, or power
        if (sizeof($requires) == 2) {   //only one value provided
            $reqVal = $requires[1];     //so ensure we have a range to work with
            if ($reqVal < 0) {  // min,max = -ve,0
                $minReq = $reqVal;
                $maxReq = 0;
            } else {        //min,max = 0,+ve
                $minReq = 0;
                $maxReq = $reqVal;
            }
        } else {
            $minReq = $requires[1]; //set the required range
            $maxReq = $requires[2];
        }
        if ($offers[sizeof($offers)  -1] == "any") {        //is the last offer 'any'?
            $allFlag = false;
        } else {
           $allFlag = true;
        }

        switch ($parmType) {
            case 'voltage':     //the offered value(s) must be WITHIN the required range
                for ($offersIndex = 1; $offersIndex < sizeof($offers); $offersIndex++ ) {
                    if (!is_string($offers[$offersIndex])) {    //ignore "any"
                        $offersValue = $offers[$offersIndex];
                        if ($allFlag) {
                            if (($offersValue < $minReq) or ($offersValue > $maxReq)) {
                                return(false);  //one value failed
                            }
                        } else {
                            if (($offersValue >= $minReq) and ($offersValue <= $maxReq)) {
                                return (true);  //one value passed
                            }
                        }

                    }
                }
                return ($allFlag);

            case 'current':
            case 'power' :     //the offered value(s) must be OUTSIDE the required range
                if (sizeof($offers) == 2) { //only one value provided
                    $offVal = $offers[1]; //so ensure we have a range to work with
                    if ($offVal < 0) { // min,max = -ve,0
                        $minOff = $offVal;
                        $maxOff = 0;
                    } else { //min,max = 0,+ve
                        $minOff = 0;
                        $maxOff = $offVal;
                    }
                } else {
                    $minOff = $offers[1]; //set the required range
                    $maxOff = $offers[2];
                }
                if ($debug) echo ("<br/>minOff=$minOff,maxOff=$maxOff,minReq=$minReq,maxReq=$maxReq<br/>");
                for ($offersIndex = 1; $offersIndex < sizeof($offers); $offersIndex++ ) {
                    if (!is_string($offers[$offersIndex])) {    //ignore "any"
                        $offersValue = $offers[$offersIndex];
                        if ($allFlag) {
                            if (($minOff > $minReq) or ($maxOff < $maxReq)) {
                                return(false);  //one value failed
                            }
                        } else {
                            if (($minOff <= $minReq) and ($maxOff >= $maxReq)) {
                                return (true);  //one value passed
                            }
                        }

                    }
                }
                return ($allFlag);

            default:
                die("unrecognised numeric parameter");
        }

    }

}

?>


