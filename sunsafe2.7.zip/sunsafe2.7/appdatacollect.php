
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2023-07-25    chris.moller@evonet.com -->
	<title>Sunsafe Appliance Data Capture 2</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2/index6.php       -->
	<meta charset="utf-8">

	<style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: lightblue;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }
 

	</style>

	
</head>

<body >

    <h1>Appliance data capture</h1>
    <p>To pre-populate this page with default values for a particular type of appliance, select the appliance, and click 'Load defaults'</p>

<?php

    //We will deliver to app2json.php:
    //mfr,model,apType,voltage,frequency,current,Runits,averagePower,Aunits,protocol, filename

    require "json_utilities.php";

    $appdata = file_get_contents("appliances.json");
    $app_data = json_decode($appdata,true);
    if (is_null($app_data)) {
        die("appliances.json is not a valid JSON file");
    }

    $appliances = $app_data["appliances"];

?>
    <form action="appdatacollect.php" method="GET" name="inputData" id="inputData">

        <select class="select1" name="apType" id="apType">

        <?php

            foreach ($appliances as $appliance) {
                $appName = $appliance["apType"];
                if ($appName != "solarPanel") {
                    echo ('    <option value="' . $appName . '">' . $appName . '</option>' . PHP_EOL);
                }
            }
        ?>
        </select>
        <input name="submit" type="submit" value="Load defaults" />


    </form>


<?php



    $apType = "";
    $defaultWatts = "27";
    $defaultVolts = "";
    $defaultFrequency = "";
    $averagePower = "";

    if (key_exists("apType", $_GET)) { //we have some default values
        $apType = $_GET["apType"];
        foreach ($appliances as $appliance) {
            if ($appliance["apType"] == $apType) {
                $defaultWatts = $appliance["defaultWatts"];
                $defaultVolts = $appliance["defaultVolts"];
                $defaultFrequency = $appliance["defaultFrequency"];
                $averagePower = $appliance["averagePower"];
                break;
            }
        }
    }

?>

    <form action="app2json.php" method="GET" name="inputData" id="inputData">

        <table>
            <tr>
                <td colspan="2" align="center">
                    <b>General</b>
                </td>
            </tr>
            <tr>
                <td align="right">Product manufacturer/brand</td>
                <td>
                    <input id="mfr" name="mfr" value="<?=$mfr?>" />
                </td><td>&nbsp;</td>
            </tr>

            <tr>
                <td align="right">Product/model number</td>
                <td>
                    <input id="model" name="model" value="<?=$model?>" />
                </td><td>&nbsp;</td>
            </tr>
            <tr>
                <td align="right">Appliance type</td>
                <td>
                    <input id="apType" name="apType" value="<?=$apType?>" />
                </td><td>&nbsp;</td>
            </tr>            <tr>
                <td colspan="2" align="center">
                    <b>Electrical characteristics</b>
                </td>
            </tr>
            <tr>
                <td align="right">Supply voltage:</td>
                <td><input id="voltage" name="voltage" value="<?=$defaultVolts?>" />
                </td><td>Volts*</td>
            </tr>
            <tr>
                <td align="right">Supply frequency:</td>
                <td><input id="frequency" name="frequency" value="<?=$defaultFrequency?>" />
                </td><td>Hz*</td>
            </tr>
            <tr>
                <td align="right">Rated power/current</td><td>
                    <input id="current" name="current" value="<?=$defaultWatts?>" />
                </td><td><select  name="Runits" id="Runits">
                    <option value="Watts" selected>Watts</option>
                    <option value="Amps">Amps</option>
                    </select></td>
             </tr>
            <tr>
                <td align="right">Average operating power/current</td><td>
                    <input id="averagePower" name="averagePower" value="<?=$averagePower?> " />
                </td><td><select  name="Aunits" id="Aunits">
                    <option value="Watts" selected>Watts</option>
                    <option value="Amps">Amps</option>
                    </select></td>        </tr>    
            <tr>
                <td align="right">Power signalling protocol</td><td>
                    <input id="protocol" name="protocol" value="(none)" />
                </td><td>&nbsp;</td>
            </tr>
            <tr>
                <td colspan="2" align="center">
                    <b>Save</b>
                </td>
            </tr>       <tr>
                <td align="right">Product data file name</td><td>
                    <input id="fileName" name="fileName" value="" />
                </td><td>.json</td>
            </tr>   
        </table>


        <input name="submit" type="submit" value="Create JSON file..." />


    </form>

    <p>* For these parameters, a range (voltage) or alternative input frequencies (frequency) may be entered, separated by commas</p>
    <p>(It would be nice to add an option for a second power input, but this hasn't been done)</p>


</body>
</html>

