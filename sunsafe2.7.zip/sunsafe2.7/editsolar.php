<?php
error_reporting(-1);
ini_set("display_errors", 1);
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2023-07-29    chris.moller@evonet.com -->

    <meta charset="utf-8" />
    <title>Sunsafe II</title>


    <style type="text/css">


		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
                table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: lightblue;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }
        td {
            text-align: right;
        }
        .button1 {
            box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
        }

	</style>

</head>
<body>

    <?php
    $script = substr(strrchr(__FILE__, "/"),1); //get the name of this file, so we can return to it after editing


 //   require "../json_utilities.php";

    if (!isset($_SESSION['componentList'])) {    //This is where the current list of components is stored
        die("no components!");
    }
    $index = $_GET["component"];
    $components = $_SESSION['componentList'];
    $component = $components[$index];

    $compName = $component["brand"] . "/" . $component["model"];

    echo("<h2>Edit generating hours for ". $compName ."</h2>");
    $dayHrs = $component["dayHrs"];


    ?>
    <form name="editform" id="editform" action="check.php" >
        <input type="hidden" name="edit" id="edit" value="<?=$index?>" />
    
        <table>
            <tr>
                <td>Average number of effective solar generating hours:</td>
                <td><input type="text" size ="2" name="dayHours" id="dayHours" value="<?=$dayHrs?>"/></td>
            </tr>
        </table>
        <input type="submit" name="submit" id="submit" value="Update"/>
    </form>


</body>
</html>