
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2023-07-25    chris.moller@evonet.com -->
	<title>Save Infrastructure JSON file</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2/generateJson.php       -->
	<meta charset="utf-8">

	<style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: lightblue;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }
 

	</style>

	
</head>

<body >

    <?php


    error_reporting(-1);
    ini_set("display_errors", 1);


    require("json_utilities.php");


    $fileName = $_GET["fileName"].".json";

    $mfr = $_GET["mfr"];
    $model = $_GET["model"];
    $bvo = intval($_GET["bvo"]);
    $usb = intval($_GET["usb"]);


    echo ("<h1>Sunsafe JSON file creation for $mfr $model</h1>");

    $energy = array();



    $data = array();
    $data['$schema'] = "../Sunsafe2.4.json";
    $data["brand"] = $mfr;
    $data["model"] = $model;

    if (key_exists("wpk",$_GET)){   //we have a solar panel
        $energy["solarWpk"] = $_GET["wpk"];
        $data["apType"] = "solarPanel"; //treat like an appliance for hours of use
    }

    $data["ports"] = array();

    if (key_exists("ocv",$_GET)) {  //we have an exposed solar panel output
        $port = array();
        $port["name"] = "Solar panel output";
        $port["function"] = ["requires","solarIn"];
        $port["elements"] = array();
        $element = array();
        $element["voltage"] = ["offers",0,floatval($_GET["ocv"])];
        if (key_exists("scc", $_GET)) {
            $element["current"] = ["requires",0, floatval($_GET["scc"])];
        }
        array_push($port["elements"],$element);
        array_push($data["ports"], $port);

    }

    if (key_exists("maxocv", $_GET)) { //we have a solar panel input

        if (key_exists("mainsV",$_GET)) {
            $minsolar = 0;  //if we also have a mains input, we won't issue a warning if there's no solar panel connected
        } else {
            $minsolar = 1;
        }
        $port = array();
        $port["name"] = "Solar panel input";
        $port["function"] = ["offers","solarIn",$minsolar,-1];
        $port["elements"] = array();
        $element = array();
        $element["voltage"] = ["requires",0, floatval($_GET["maxocv"])];
        if (key_exists("maxscc", $_GET)) {
            $element["current"] = ["offers",0, floatval($_GET["maxscc"])];
        }
        array_push($port["elements"],$element);
        array_push($data["ports"],$port);
    }

    if (key_exists("mainsV", $_GET)) { //we have a mains input
        $port = array();
        $port["name"] = "Mains in";
        $port["function"] = ["requires","ACsupply"];
        $port["elements"] = array();
        $element = array();

        $mainsVolts = explode(",", $_GET["mainsV"]);
        if (sizeof($mainsVolts) == 1) {
            array_push($mainsVolts, $mainsVolts[0]); //make max and min the same
        }
        $mainsVolts[0] = floatval($mainsVolts[0]);
        $mainsVolts[1] = floatval($mainsVolts[1]);
        $mainsVolts = array_prepend($mainsVolts, "requires");
        $element["voltage"] = $mainsVolts;

        //we cheat here, making each one a string with "Hz", to force the checker
        //to only consider discrete values
        if (key_exists("mainsF",$_GET)) {
            $powerF = explode(",",$_GET["mainsF"]);
//            $powerF = array_map("floatval", $powerF);
//            $powerF = array_map("strval", $powerF);
            foreach($powerF as &$powerF1) { //this is the way to update every element of the array
                $powerF1 = $powerF1 . "Hz";
            }
            unset($powerF1);
            $powerF = array_prepend($powerF, "requires");
            $element["frequency"] = $powerF;
        }

        if (key_exists("mainsA", $_GET)) {
            $mainsCurrent = floatval($_GET["mainsA"]);
            $element["current"] = ["requires",0, $mainsCurrent];
            $energy["perHour"][] = ["offers",min($mainsVolts[0],$mainsVolts[1]) * $mainsCurrent];
        }
        array_push($port["elements"], $element);
        array_push($data["ports"], $port);

    }

    if (key_exists("ctlBattVolts", $_GET)) { //we have a battery port
        $port = array();
        $port["name"] = "Battery connection";
        $port["function"] = ["offers","batteryPort",1,-1];  //there must be at least one battery connected to the battery port
        $port["elements"] = array();
        $element = array();
        $battV = $_GET["ctlBattVolts"];
        $battV = explode(",", $battV);
        $battV = array_prepend($battV,"offers");
        $element["voltage"] = $battV;
        $element["current"] = ["offers", $_GET["ctlBattAmps"]];
        if (key_exists("ctlChem", $_GET)) {
            $Chem = array();
            $Chem = $_GET["ctlChem"];
            $Chem = array_prepend($Chem, "requires");
             $element["ctlChem"] = $Chem;
        }
        if (key_exists("bmsProtocol", $_GET)) {
            $element["BMSmaster"] = ["offers", $_GET["bmsProtocol"]];
        }
        array_push($port["elements"], $element);
        array_push($data["ports"], $port);
    }

    if (key_exists("battVolts", $_GET)) { //we have a battery
        $port = array();
        $port["name"] = "Battery";
        $port["function"] = ["requires","batteryPort"];
        $port["elements"] = array();
        $element = array();
        $battV1 = $_GET["battVolts"];
        $battVolts = explode(",", $battV1);
        if (sizeof($battVolts)==1) {
            array_push($battVolts,$battVolts[0]);   //make max and min the same
        }
        $battVolts[0] = floatval($battVolts[0]);
        $battVolts[1] = floatval($battVolts[1]);
        $battVolts = array_prepend($battVolts, "requires");
        $element["voltage"] = $battVolts;
        if (key_exists("battChem", $_GET)) {
            $element["chemistry"] = ["offers",$_GET["battChem"]];
        }
        if (key_exists("battBMS",$_GET)){
            $element["BMSmaster"] = ["requires", $_GET["battBMS"]];
        }
        array_push($port["elements"], $element);
        array_push($data["ports"], $port);
    }
    if (key_exists("battAh",$_GET)){
        $energy["storage"] = $_GET["battAh"];
        $energy["storageEfficiency"] = $_GET["battEff"];
    }

    for ($bvoCount = 0; $bvoCount < $bvo; $bvoCount++) {
        $index = strval($bvoCount + 1);
        if (key_exists("nomVolts".$index,$_GET)) {
            $port = array();
            if ($bvo == 1) {
                $port["name"] = "DC output";
            } else {
                $port["name"] = "DC output_$index";
            }
            $port["function"] = ["offers","LVDCsupply",0,-1];   //we can connect any number of DC loads, or none
            $port["elements"] = array();
            $element = array();
            $nomVolts = $_GET["nomVolts".$index];
            if ($nomVolts == "=Battery voltage") {
                $nomVolts = [$nomVolts];
            } else {
                $nomVolts = explode(",", $nomVolts);
                $nomVolts = array_map('floatval', $nomVolts);
                if (sizeof($nomVolts) > 1) {
                    array_push($nomVolts, "any");
                }
            }
            $nomVolts = array_prepend($nomVolts,"offers");
            $element["voltage"] = $nomVolts;
            $nomA = $_GET["nomAmps".$index];
            $nomU = $_GET["Dunits".$index];
            $element["current"] = ["offers", $nomA,$nomU];
            $element["protocol"] = ["offers", $_GET["bvoProtocol" . $index]];
            array_push($port["elements"], $element);
            array_push($data["ports"], $port);
        }
    }

    for ($usbCount = 0; $usbCount < $usb; $usbCount++) {
        $index = strval($usbCount + 1);
        if (key_exists("usbVolts".$index,$_GET)) {
            $port = array();
            if ($usb == 1) {
                $port["name"] = "USB output";
            } else {
                $port["name"] = "USB output_$index";
            }
            $port["function"] = ["offers", "USBout",0,1];   //we can only connect one USB load, or none
            $port["elements"] = array();
            $element = array();
            $usbVolts = $_GET["usbVolts".$index];
            $usbVolts = explode(",", $usbVolts);
            $usbVolts = array_map('floatval', $usbVolts);
            if (sizeof($usbVolts) > 1) {
                array_push($usbVolts, "any");
            }
            $usbVolts = array_prepend($usbVolts, "offers");
            $element["voltage"] = $usbVolts;
            $usbA = floatval($_GET["usbAmps".$index]);
            $usbU = $_GET["Uunits".$index];
            $element["current"] = ["offers",$usbA,$usbU];
            }
            $element["protocol"] = ["offers",$_GET["usbProtocol".$index]];
            array_push($port["elements"], $element);
            array_push($data["ports"], $port);
    }

    if (key_exists("ACpwr", $_GET)) { //we have a mains output
        $port = array();
        $port["name"] = "Mains output";
        $port["function"] = ["offers","ACsupply",0,-1]; //we can connect any number of AC loads, or none
        $port["elements"] = array();
        $element = array();
        if (key_exists("ACvout", $_GET)) {
            $mainsV = floatval($_GET["ACvout"]);
            $element["voltage"] = ["offers", $mainsV];
        }
        if (key_exists("ACfreq", $_GET)) {
            $mainsF = $_GET["ACfreq"];
            $element["frequency"] = ["offers", $mainsF."Hz"];
        }
        if (key_exists("ACpwr", $_GET)) {
            $element["current"] = ["offers",0, dp2(floatval($_GET["ACpwr"])/$mainsV)];
        }
        array_push($port["elements"], $element);
        array_push($data["ports"], $port);
    }

    if (key_exists("invInVolts", $_GET)) { //we have an inverter with LVDC input
        $port = array();
        $port["name"] = "DC power in";
        $port["function"] = ["requires","LVDCsupply"];
        $port["elements"] = array();
        $element = array();

        $invInV1 = $_GET["invInVolts"];
        $invInVolts = explode(",", $invInV1);
        if (sizeof($invInVolts) == 1) {
            array_push($invInVolts, $invInVolts[0]); //make max and min the same
        }
        $invInVolts[0] = floatval($invInVolts[0]);
        $invInVolts[1] = floatval($invInVolts[1]);
        $invInVolts = array_prepend($invInVolts, "requires");
        $element["voltage"] = $invInVolts;
        if (key_exists("ACpwr", $_GET)) {
            $invInA = floatval($_GET["ACpwr"]) / $invInVolts[1];
            if(key_exists("FLeff",$_GET)) {
                $invInA = $invInA * 100 / (floatval($_GET["FLeff"]));
            }
            $element["current"] = ["requires",dp2($invInA)];
        }
        array_push($port["elements"], $element);
        array_push($data["ports"], $port);
    }

/*
    if ($_GET["Aunits"] == "Amps") {
        $averagePower = $powerVolts[2] * floatval($_GET["averagePower"]);
    } else {
        $averagePower = $_GET["averagePower"];
    }
*/

    if (key_exists("loss",$_GET)) {
        $energy["perHour"][] = ["requires",$_GET["loss"]];
    }
    if (key_exists("eff", $_GET)) { //this is going to need to be much cleverer
        $energy["efficiency"] = $_GET["eff"];
    }

    $data["energy"] = $energy;




    $fileName = $_GET["fileName"].".json";

    $fileText = json_encode($data);

//    echo ($fileText);

    $myfile = fopen("data/".$fileName,"w");
    fwrite($myfile,$fileText);
    fclose($myfile);



    echo ("<p>File $fileName successfully created</p>");



    ?>

    <form action="phpqrcode/p2.php" method="GET" name="inputData" id="inputData">
        <input type="hidden" id="file" name="file" value="<?=$fileName?>" />

        <input name="submit" type="submit" value="View the created JSON data..." />

    </form>

</body>
</html>

