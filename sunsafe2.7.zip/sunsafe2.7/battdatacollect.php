
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2023-07-25    chris.moller@evonet.com -->
	<title>Sunsafe Battery Data Capture</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2.7/battdatacollect.php       -->
	<meta charset="utf-8">

	<style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: lightblue;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }
 

	</style>

	
</head>

<body >

<?php


/* This has to deliver to batt2json.php:
 *     mfr, model,  voltage, charge, discharge, protocol, capacity, capUnits, eff
 *     ie  voltage, charge current, discharge current, protocol, storage capacity, watt-hours or amp-hours, roundtrip efficiency

*/


?>


<form action="batt2json.php" method="GET" name="inputData" id="inputData">

    <table>
        <tr>
            <td colspan="2" align="center">
                <b>General</b>
            </td>
        </tr>
        <tr>
            <td align="right">Product manufacturer/brand</td>
            <td>
                <input id="mfr" name="mfr" value="" />
            </td><td>&nbsp;</td>
        </tr>
        <tr>
            <td align="right">Product/model number</td>
            <td>
                <input id="model" name="model" value="" />
            </td><td>&nbsp;</td>
        </tr>
        <tr>
            <td colspan="2" align="center">
                <b>Electrical characteristics</b>
            </td>
        </tr>
        <tr>
            <td align="right">Nominal battery voltage:</td>
            <td><input id="voltage" name="voltage" value="12" />
            </td><td>Volts</td>
        </tr>
        <tr>
            <td align="right">Battery storage capacity:</td>
            <td><input id="capacity" name="capacity" value="" />
            </td><td><select  name="capUnits" id="capUnits">
                <option value="Wh" >Watt-hours</option>
                <option value="Ah">Amp-hours</option>
                </select></td>
        </tr>
        <tr>
            <td align="right">Maximum charging current (leave blank if unknown):</td>
            <td>
                <input id="charge" name="charge" value="" />
            </td><td>Amps</td>
        </tr>
        <tr>
            <td align="right">Maximum discharge current (leave blank if unknown):</td>
            <td>
                <input id="discharge" name="discharge" value="" />
            </td><td>Amps</td>
        </tr>
        <tr>
            <td align="right">Battery chemistry or charging protocol:</td>
            <td colspan="2"><select  name="protocol">
                    <option>Lead-acid VRLA</option>
                    <option>Wet lead-acid</option>
                    <option>Lead-acid AGM</option>
                    <option>Lithium Iron Phosphate (LiFePO4)</option>
                    <option>Lithium Iron Phosphate (LiFePO4) with CANbus BMS</option>
                    <option>Lithium–nickel–manganese–cobalt oxides (NMC)</option>
                    <option>Li-ion</option>
                    <option>Nickel-Cadmium (NiCd)</option>
                </select>

            </td><td>&nbsp;</td>
        </tr>
        <tr>
            <td align="right">Round trip efficiency</td><td>
                <input id="eff" name="eff" value="85" />
            </td><td>%</td>
        </tr>
        <tr>
            <td colspan="2" align="center">
                <b>Save</b>
            </td>
        </tr>       <tr>
            <td align="right">Product data file name</td><td>
                <input id="fileName" name="fileName" value="" />
            </td><td>.json</td>
        </tr>   
    </table>


        <input name="submit" type="submit" value="Create JSON file..." />


</form>




</body>
</html>

