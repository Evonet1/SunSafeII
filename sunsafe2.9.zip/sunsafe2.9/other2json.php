
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2023-07-25    chris.moller@evonet.com -->
	<title>Save Infrastructure JSON file</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2.7/other2json.php       -->
	<meta charset="utf-8">

	<style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: lightblue;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }
 

	</style>

	
</head>

<body >

    <?php


    error_reporting(-1);
    ini_set("display_errors", 1);

    /* This generates a JSON file for a complex component
     * inputs are:
            mfr
            model
            wpk
            ocv
            scc
            maxConns
              iname[]
              ivoltage[]
              ifrequency[]
              icurrent[]
              iunits[]
            battV
            battA
            ctlChem[]
            battCap
            battEff
              oname[]
              ovoltage[]
              ofrequency[]
              ocurrent[]
              ounits[]

    */

    define("VERSION" , "2.9");

    require("json_utilities.php");


    $fileName = $_GET["fileName"].".json";

    $mfr = $_GET["mfr"];
    $model = $_GET["model"];


    echo ("<h1>Sunsafe JSON file creation for $mfr $model</h1>");



    $data = array();
    $energy = array();

    $data['$schema'] = "sunsafe".VERSION.".json";
    $data["brand"] = $mfr;
    $data["model"] = $model;
    $ports = array();

    //Deal with solar input
    if (key_exists("ocv", $_GET)) {
        $ocv = checkKey("ocv");
        $scc = checkKey("scc");
        $maxConns = checkKey("maxConns");
        $maxConns = intval($maxConns);
        if ($maxConns == -1) {
            $maxConns = "U";
        }
        $port = array();
        $port["name"] = "SolarIn";
        $port["function"] = ["offers", "solarIn"];
        $port["connections"] = ["offers", $maxConns];
        $port["voltage"] = ["offers", 0, floatval($ocv)];
        $port["ampsWatts"] = ["offers", -floatval($scc), "A"];
        $port["protocol"] = ["offers", "solarIn"];
        array_push($ports, $port);
    }

    //deal with any number of general inputs
    if (key_exists("iname",$_GET)) {
        $inames = $_GET["iname"];
        for ($iindex = 0; $iindex < sizeof($inames); $iindex++) {
            $iname = $inames[$iindex];
            $ivolts = $_GET["ivoltage"][$iindex];
            $ifrequency = $_GET["ifrequency"][$iindex];
            $iAW = $_GET["iampsWatts"][$iindex];
            $iunits = $_GET["iunits"][$iindex];
            $iprotocol = $_GET["iprotocol"][$iindex];


            if ($ivolts == "") {
                die("Voltage must be specified");
            }

            $ivoltage = array_map("floatval", explode(",", $ivolts)); //voltage will always be an array of numbers
            if (sizeof($ivoltage) == 1) {
                $nomVolts = floatval($ivoltage[0]); //a required voltage should always be a range
                $minVolts = dp2($nomVolts * 0.95); //so assume at least a +-5% tolerance
                $maxVolts = dp2($nomVolts * 1.05);
                $ivoltage[0] = $minVolts;
                $ivoltage[1] = $maxVolts;
            }
            $ivoltage = array_prepend($ivoltage, "requires");

            if ($ifrequency == "") {
                $ifrequency = ["0Hz"];
            } else {
                $ifrequency = explode(",", $ifrequency);
                foreach ($ifrequency as &$f1) {
                    if (($f1 == "DC") or ($f1 == "dc")) {
                        $f1 = "0Hz";
                    } else {
                        $f1 = $f1 . "Hz";
                    }
                }
            }
            $ifrequency = array_prepend($ifrequency, "requires");

            $port = array();
            $port["name"] = $iname;
            $port["function"] = ["requires", "output"];
            $port["connections"] = ["requires", 1];
            $port["voltage"] = $ivoltage;
            $port["ampsWatts"] = ["requires",$iAW,$iunits];
            $port["frequency"] = $ifrequency;
            $port["protocol"] = ["requires", $iprotocol];
            array_push($ports, $port);
        }

    }

    //Deal with an exposed battery port
    if (key_exists("battV", $_GET)) {
        $battV = checkKey("battV");
        $battA = checkKey("battA");
        $battConns = checkKey("battConns");
        $battConns = intval($battConns);
        if ($battConns == -1) {
            $battConns = "U";
        }
        $port = array();
        $port["name"] = "battPort";
        $port["function"] = ["offers", "battPort"];
        $port["connections"] = ["offers",$battConns];
        $battV1 = explode(",", $battV); //several different discrete nominal voltages may be supported
        $battV1 = array_map("floatval", $battV1);
        $battV2 = array_prepend($battV1, "offers");
        $port["voltage"] = $battV2;
        $pcol = $_GET["ctlChem"];
        $pcol1 = array_prepend($pcol, "offers");
        $port["protocol"] = $pcol1;
        array_push($ports, $port);
    }

    //Deal with battery energy
    if (key_exists("capacity", $_GET)) {
        $capacity = $_GET["capacity"];
        $battEff = $_GET["battEff"];
        $energy["capacity"] = $capacity;
        $energy["battEff"] = $battEff;
    }





    //deal with any number of general outputs
    if (key_exists("oname", $_GET)) {
        $onames = $_GET["oname"];
        for ($oindex = 0; $oindex < sizeof($onames); $oindex++) {
            $oname = $onames[$oindex];
            $ovolts = $_GET["ovoltage"][$oindex];
            $ofrequency = $_GET["ofrequency"][$oindex];
            $oAW = $_GET["oAW"][$oindex];
            $loadConns = $_GET["loadConns"][$oindex];
            if ($loadConns  == -1) {
                $loadConns = "U";
            }
            $ounits = $_GET["ounits"][$oindex];
            $oprotocol = $_GET["oprotocol"][$oindex];


            if ($ovolts == "") {
                die("Voltage must be specified");
            }

            $ovoltage = array_map("floatval", explode(",", $ovolts)); //voltage may be several numbers separated by commas
            $ovoltage = array_prepend($ovoltage, "offers");

            if ($ofrequency == "") {
                $ofrequency = ["0Hz"];
            } else {
                $ofrequency = explode(",", $ofrequency);
                foreach ($ofrequency as &$f1) {
                    if (($f1 == "DC") or ($f1 == "dc")) {
                        $f1 = "0Hz";
                    } else {
                        $f1 = $f1 . "Hz";
                    }
                }
            }
            $ofrequency = array_prepend($ofrequency, "offers");

            $port = array();
            $port["name"] = $oname;
            $port["function"] = ["offers", "output"];
            $port["connections"] = ["offers", $loadConns];
            $port["voltage"] = $ovoltage;
            $port["ampsWatts"] = ["offers", floatval($oAW),$ounits];
            $port["frequency"] = $ofrequency;
            $port["protocol"] = ["offers", $oprotocol];
            array_push($ports, $port);
        }

    }



    //system energy parameters

    $loss = $_GET["loss"];
    $efficiency = $_GET["efficiency"];
    $energy["perDay"] = -dp2($loss * 12);
    $energy["perNight"] = -dp2($loss * 12);
    $energy["efficiency"] = $efficiency;




    $data["ports"] = $ports;

    $data["energy"] = $energy;




    $fileName = $_GET["fileName"].".json";

    $fileText = json_encode($data, JSON_PRETTY_PRINT);

//    echo ($fileText);

    $myfile = fopen("data/".$fileName,"w");
    fwrite($myfile,$fileText);
    fclose($myfile);



    echo ("<p>File $fileName successfully created</p>");



    ?>

    <form action="phpqrcode/p2.php" method="GET" name="inputData" id="inputData">
        <input type="hidden" id="file" name="file" value="<?=$fileName?>" />

        <input name="submit" type="submit" value="View the created JSON data..." />

    </form>

</body>
</html>

