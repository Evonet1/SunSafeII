
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2023-07-25    chris.moller@evonet.com -->
	<title>Add an appliance</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2/index6.php       -->
	<meta charset="utf-8">

	<style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: lightblue;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }

	</style>

	
</head>

<body >

<h2>Add a component from a JSON file</h2>

<p>Select the component you wish to add.</p>

    <form action="check.php">

        <?php

    echo ('<select name="addFile" id="addFile" >');

    $files = scandir('data');
    print_r($files);
    foreach ($files as $file) {
        if (str_ends_with(strtolower($file), '.json')) {
            $appdata = file_get_contents("data/".$file,true);
            $app_data = json_decode($appdata,true);
            if (is_null($app_data)) {
            } else {
                if (key_exists("apType", $app_data)) {
                    $prompt = $app_data["apType"] . " (" . $app_data["brand"] . " " . $app_data["model"] . ")";
                } else {
                    $prompt = $app_data["brand"] . " " . $app_data["model"];
                }
                echo ('    <option value="' . $file . '">' . $prompt . '</option>' . PHP_EOL);
            }
        }
    }
    echo ('</select>');

        ?>
        <br/>
        <input name="submit" type="submit" value="Next..." />


</form>




</body>
</html>

