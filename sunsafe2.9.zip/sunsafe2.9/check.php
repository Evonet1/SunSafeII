<?php
error_reporting(-1);
ini_set("display_errors", 1);
session_start();

$debug = false;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2023-07-29    chris.moller@evonet.com -->

    <meta charset="utf-8" />
    <title>Sunsafe II</title>


    <style type="text/css">


		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 1px solid black;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: white;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 1px solid black;
        }
        td {
            text-align: center;
        }
        .button1 {
            box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
        }

	</style>

</head>
<body>

    <?php


 //   require "../json_utilities.php";
    require "rulecheck.php";

    if ((!isset($_SESSION['componentList'])) or (key_exists("reset",$_GET))) {    //This is where the current list of components is stored
        $_SESSION['componentList'] = array();
        echo ("Resetting session!");
    }
    $_SESSION['netlist'] = array();     //start with an empty netlist

    $script = substr(strrchr(__FILE__, "/"),1); //get the name of this file, so we can return to it after adding/deleting

    if (key_exists("remove",$_GET)) {
        $del_index = $_GET["remove"];
        array_splice($_SESSION['componentList'], $del_index, 1, []);
    }


    if (key_exists("addFile", $_GET)) {
        $file = $_GET["addFile"];
        if (str_ends_with(strtolower($file), '.json')) {
            $appdata = file_get_contents("data/" . $file, true);
            $app_data = json_decode($appdata, true);
            if (!is_null($app_data)) {
                $_SESSION["componentList"][] = $app_data;
            }
        }
    }

    if (key_exists("edit", $_GET)) {
        $index = $_GET["edit"];
        $component = $_SESSION["componentList"][$index];
        $energy = $component["energy"];
        $energy["dayHrs"] = $_GET["dayHours"];
        if (key_exists("nightHours",$_GET)) {
            $energy["nightHrs"] = $_GET["nightHours"];
        }
        $component["energy"] = $energy;
        $_SESSION["componentList"][$index] = $component;
        echo ("updated");
    }

    ?>
    <h2>Solar Home System Builder</h2>

    <p>Add components to the system as required.</p>
    <table border="1" cellspacing="0">
        <tr>
            <td rowspan="2">&nbsp;</td>
            <td align="center" rowspan="2" width="150"><b>Component</b></td>
            <td align="center" colspan="2"><b>hrs/day</b></td>
            <td rowspan="2"><b><a href="<?=$script?>?reset=1">X</a></b></td>
        </tr>
        <tr>
            <td><img src="img/day.jpg" width="25"/></td><td><img src="img/night.jpg" width="25"/></td>
        </tr>

        <?php
        $defaultData = file_get_contents("appliances.json", true);  //pre-load default appliance data
        $default_data = json_decode($defaultData, true);
        $defaultAppliances = $default_data["appliances"];

        $index = 0;
        foreach($_SESSION['componentList'] as $component) {
            $dayHrs = "&nbsp;";
            $nightHrs = "&nbsp;";
            if (is_array($component)) {
                if (key_exists("apType", $component)) { //we have an appliance
                    $apType = $component["apType"];
                    $prompt = $apType. "<br/>(" . $component["brand"] . " " . $component["model"] . ")";
                    if (key_exists("energy",$component)) {
                        $energy = $component["energy"];
                        if (key_exists("dayHrs",$energy)) {
                            $dayHrs = $energy["dayHrs"];
                        }
                        if (key_exists("nightHrs",$energy)) {
                            $nightHrs = $energy["nightHrs"];
                        }
                    }
                    if (($dayHrs == "&nbsp;") or ($nightHrs == "&nbsp;")){  //hrs of use have not been set, so use defaults
                        foreach ($defaultAppliances as $defaultAppliance) {
                            if ($defaultAppliance["apType"] == $apType) {
                                if (key_exists("defaultDayHours", $defaultAppliance)) {
                                    $dayHrs = $defaultAppliance["defaultDayHours"];
                                }
                                if (key_exists("defaultNightHours", $defaultAppliance)) {
                                    $nightHrs = $defaultAppliance["defaultNightHours"];
                                }
                                break;
                            }
                        }
                    }
                    if ($apType == "solarPanel") {
                        $tableRow = '<tr><td>' . $index . '</td><td><a href="editsolar.php?component=' . $index . '">' . $prompt . '</a>';
                    } else {
                        $tableRow = '<tr><td>'.$index.'</td><td><a href="edit.php?component=' . $index . '">' . $prompt . '</a>';
                    }
                } else {
                    $prompt = $component["brand"] . " " . $component["model"];
                    $tableRow = '<tr><td>' . $index . '</td><td>'.$prompt;
                    $dayHrs = "&nbsp;";
                    $nightHrs = "&nbsp;";
                }
                $tableRow .= '</td><td align="center">'.$dayHrs.'</td><td align="center">' . $nightHrs . '</td>';
                $tableRow.= '<td align="center"><a href="'.$script.'?remove=' . $index . '">X</a></td></tr>';
                echo ($tableRow);
                $component["dayHrs"] = $dayHrs;
                $component["nightHrs"] = $nightHrs;
                $_SESSION["componentList"][$index] = $component;
            }
            $index++;
        }
        ?>

        <tr>
            <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>X</td>
        </tr>
        <tr>
            <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>X</td>
        </tr>

    </table>
    <br/>
    <button class="button1" name="readQR" id="readQR" onclick="location.href='readQR.php'" disabled>Read QR code label</button><br/><br/>
    <button class="button1" name="addInf" id="addInf" onclick="location.href='add.php'">Add component from file</button><br /><br />

    <?php
    //now find out which ports are going to be connected together
    $components = $_SESSION["componentList"];
    $connectionLimits = array();    //This is going to contain component#, port#, minConn, maxConn for every port

    //don't use foreach, as we're going to modify the controlling variable
    for ($componentIndex1 = 0;$componentIndex1 < sizeof($components); $componentIndex1++) {
        $component1 = $components[$componentIndex1];  //check every port of every component
        $portIndex1 = 0;
        foreach ($component1["ports"] as $port1) {            //we are scanning all ports of all components
            if ($debug) echo ("Checking component[$componentIndex1] " . brandModelPort($componentIndex1,$portIndex1) . "<br/>");
            $function1 = $port1["function"];

            //populate array of minimum and maximum port connections
            $minConn = 1;
            $maxConn = 1;
            if ($function1[0] == "offers") {
                if (sizeof($function1) == 4) { //we have information about the number of permitted connections
                    $minConn = $function1[2];
                    $maxConn = $function1[3];
                }
            }
            $connectionLimits[$componentIndex1][$portIndex1] = $port1["connections"];       //build an array of all the limits of all ports

            if ($debug)  echo ("&nbsp;&nbsp;port ".$port1["name"]."<br/>");
            $reason = "";       //put the reason for any failure to match here

            if ($function1[0] == "requires") {   //we have a need that must be fulfilled
                $match = false;
                //check all other ports, to find out which are suitable
                //don't use foreach, as we're going to modify the controlling variable
                for ($componentIndex2 = 0;$componentIndex2 < sizeof($components); $componentIndex2++) {
                    $component2 = $components[$componentIndex2]; //check every port of every component for a match with port1
                    if ($componentIndex2 != $componentIndex1) { //we don't want to connect to ourselves!
                        $ports2 = $component2["ports"];
                        for ($portIndex2 = 0;$portIndex2 < sizeof($ports2);$portIndex2++) {
                            $port2 = $ports2[$portIndex2];
                            if (prelimCheck($port1,$port2,"function")) {
                                //now check voltage, current and frequency to see if they're also suitable
//                                $element1 = $port1["elements"][0];    //we only have one element for now
//                                $element2 = $port2["elements"][0];
                                if (prelimCheck($port1,$port2,"voltage")) {
                                    if ((key_exists("ampsWatts",$port1) and (key_exists("ampsWatts",$port2)))) {
                                        if (end($port1["ampsWatts"]) == "W") {  //convert watts to amps if necessary
                                            $port1["current"] = [$port1["ampsWatts"][0], (floatval($port1["ampsWatts"][1]) / floatval($port1["voltage"][1]))];
                                        } else {
                                            $port1["current"] = [$port1["ampsWatts"][0], floatval($port1["ampsWatts"][1])];
                                        }
                                        if (end($port2["ampsWatts"]) == "W") {
                                            $port2["current"] = [$port2["ampsWatts"][0],(floatval($port2["ampsWatts"][1]) / floatval($port2["voltage"][1]))];
                                        } else {
                                            $port2["current"] = [$port2["ampsWatts"][0],floatval($port2["ampsWatts"][1])];
                                        }
                                        if ($debug) echo ("port1.current=".print_r($port1["current"],true)."<br/>");
                                        if ($debug) echo ("port2.current=" . print_r($port2["current"], true) . "<br/>");
                                    }
                                    if (prelimCheck($port1,$port2,"current")) {
                                        if (prelimCheck($port1,$port2,"frequency")) {
                                            if (prelimCheck($port1, $port2, "protocol")) {
                                                $match = true;
                                                array_push($_SESSION["netlist"], [$componentIndex1, $portIndex1, $componentIndex2, $portIndex2, $function1[1]]);
                                            } else {
                                                $reason = "Incompatible protocol";
                                            }
                                        } else {
                                            $reason = "Frequency incompatible";
                                        }
                                    } else {
                                        $reason = "Current insufficient";
                                    }
                                } else {
                                    $reason = "Voltage out of range";
                                }
                            } else {
                                $reason = "No suitable port";
                            }
                        }
                    }
                    if ($match) {
                        break;
                    }
                }
                if (!$match) {
                    echo("<p>Warning: Component ".brandModelPort($componentIndex1,$portIndex1)." does not have a suitable port to connect to - Reason: $reason</p>");
                }

            }
            $portIndex1++;
        }
    }

    echo ("<h3>Connection netlist</h3>");

    //We need to check the connection quantity limits
    for ($index = 0; $index < sizeof($_SESSION["netlist"]); $index++) {
        //don't use foreach, as we're going to modify the controlling variable
        $netl = $_SESSION["netlist"];
//        echo ("Netlist now has " . sizeof($netl) . " entries<br/>");
        $netlist = $netl[$index];   //this is the particular netlist entry we are checking
        for ($limIndex = 0; $limIndex < 3 ; $limIndex +=2) {    //do both halves of the netlist (0,1 and 2,3)
            $comp = $netlist[$limIndex];
            $port = $netlist[$limIndex + 1];
            $otherComp = $netlist[2 - $limIndex];   //2,3 and 0,1
            $otherPort = $netlist[3 - $limIndex];
            $conn0 = $connectionLimits[$comp][$port][1];  //find the limits associated with the port in this netlist entry
            $conn1 = $connectionLimits[$otherComp][$otherPort][1];
//            echo ("Port $comp,$port has limits $minConn,$maxConn<br/>");
            if (($conn0 == 0) or ($conn1 == 0)) {   //no connections left
                array_splice($netl, $index, 1);   //remove the invalid connection
                $_SESSION["netlist"] = $netl;
                echo("<p>Warning: Component ".brandModelPort($otherComp,$otherPort)." does not have a suitable port to connect to - Reason: Connection limit exceeded</p>");
            }
            $connectionLimits[$comp][$port][1] = decrementConn($conn0);
            $connectionLimits[$otherComp][$otherPort][1] = decrementConn($conn1);
        }
//        echo ("Connection Limits:");
//        print_r($connectionLimits);
    }

//    echo ("<br/>Netlist:");
//    print_r($_SESSION["netlist"]);
//    echo ("<br/>");
    foreach ($_SESSION["netlist"] as $netlist) {
        //[Component1, port1, component2, port2, function]
        $portID1 = brandModelPort($netlist[0],$netlist[1]);
        $portID2 = brandModelPort($netlist[2],$netlist[3]);
        echo ($portID1." <b>to</b> ".$portID2." <b>(".$netlist[4] .")</b><br/>");
    }


//===========================================================================================================
//Assorted utility subroutines

function brandModelPort($net0,$net1) {
    $comp = $_SESSION["componentList"][$net0];
    $port = $comp["ports"][$net1];
    $portID = $net0.",".$net1." (". brandModel($comp). "." . $port["name"].")";
    return($portID);
}

function brandModel($component) {
    $product = $component["brand"] . "/" . $component["model"];
    return ($product);

}

function decrementConn($conn) {
    //decrement the connection count, unless it's "U"
    if ($conn != "U") {
        return ($conn - 1);
    }
        return ("U");
}


    ?>


</body>
</html>