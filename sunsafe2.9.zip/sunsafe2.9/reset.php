<?php
session_unset();
echo ("All clear");
?>