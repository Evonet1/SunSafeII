
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2023-07-25    chris.moller@evonet.com -->
	<title>Sunsafe Solar Panel Data Capture</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2.7/solardatacollect.php       -->
	<meta charset="utf-8">

	<style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: lightblue;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }
 

	</style>

	
</head>

<body >

<?php


/* This has to deliver to solar2json.php:
 *     mfr, model, ocv, scc, wpk, filename

*/


?>


<form action="solar2json.php" method="GET" name="inputData" id="inputData">

    <table>
        <tr>
            <td colspan="2" align="center">
                <b>General</b>
            </td>
        </tr>
        <tr>
            <td align="right">Product manufacturer/brand</td>
            <td>
                <input id="mfr" name="mfr" value="" />
            </td><td>&nbsp;</td>
        </tr>
        <tr>
            <td align="right">Product/model number</td>
            <td>
                <input id="model" name="model" value="" />
            </td><td>&nbsp;</td>
        </tr>
        <tr>
            <td colspan="2" align="center">
                <b>Electrical characteristics</b>
            </td>
        </tr>
        <tr>
            <td align="right">Maximum open-circuit voltage:</td>
            <td><input id="ocv" name="ocv" value="0" />
            </td><td>Volts</td>
        </tr>
        <tr>
            <td align="right">Maximum short-circuit current:</td>
            <td><input id="scc" name="scc" value="0"" />
            </td><td>Amps</td>
        </tr>
        <tr>
            <td align="right">Rated peak power</td><td>
                <input id="wpk" name="wpk" value="0" />
            </td><td>Watts</td>
         </tr>
        <tr>
            <td colspan="2" align="center">
                <b>Save</b>
            </td>
        </tr>       <tr>
            <td align="right">Product data file name</td><td>
                <input id="fileName" name="fileName" value="" />
            </td><td>.json</td>
        </tr>   
    </table>


        <input name="submit" type="submit" value="Create JSON file..." />


</form>




</body>
</html>

