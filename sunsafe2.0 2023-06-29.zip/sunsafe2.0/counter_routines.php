<?php

/*

Contents
========

Counter routines - test with test_counter.php
----------------
initialise_counter($elements)
get_counter()
increment($i)


*/



$counter = 0;   //static global value
$n_ary = 0;
$counter_size = 0;

// With an array of size m, the counter will return all possible values of each element in turn

function initialise_counter($elements) {
    // Initialise the counter and set its size to the number of elements
    //  and the number of possible values of each digit to the number of options for this element
    global $counter,$n_ary,$counter_size;

    $total_count = 1;

    $counter_size = count($elements);
    $counter = array();     //empty array
    $n_ary = array();       //empty array
    foreach($elements as $index=>$element) {
        if (!is_array($element["voltageSource"])) {
            $this1 = 1;
        } else {
            $this1 = count($element["voltageSource"]);
        }
        $total_count *= $this1;
        array_push($n_ary, $this1);
        array_push($counter,0); //initialise this count
    }
    report ("Initialising counter for $total_count combinations of values",3);
    report_var2("N_ary",$n_ary,4);
}

function get_counter() {
    //get the next counter value, then increment
    // return an array result[m]
    // each element is 0...n-1
    // return null when the limit is reached
    global $counter,$n_ary,$counter_size;

    $result = $counter; //increment afterwards
/*    echo("Counter=");
    print_r($counter);
    echo("<br/>");  */
    if ($result == 0) {
        return null;    //overflowed or not initialised
    }

    increment(0);

    return $result;
} 

function increment($i) {
    global $counter,$n_ary,$counter_size;
    $index = $i;
    $counter[$index]++;
    if ($counter[$index] >= $n_ary[$index]) {
        $counter[$index] = 0;
        $index++;
        if ($index < $counter_size) {
            increment($index);
        } else {
            $counter = 0;   //overflow
        }
    }
}

