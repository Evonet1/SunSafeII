<?php

error_reporting(-1);
ini_set("display_errors",1);


require "counter_routines.php";
require "element_times.php";
require "simplify.php";
require "solve_circuit.php";
/*require "derange.php";
require "find_type.php";
require "validate_element.php";
require "add_keys.php";  */
require "json_utilities.php";
require "add_paths.php";
require "elect_compat.php";
require "conn_compat.php";
require "earth_compat.php";
require "pcol_compat.php";
require "energy_compat.php";

$diagnostics = "";
$stop_on_fail = false;
$logging_level = 0;
/*
Logging values:
0 - Just pass/fail for each node
1 - Include WARNING messages
2 - Report stages of progess
3 - Detailed diagostics
4 - Very detailed diagnostics
*/
$e_check = 0;
$c_check = 0;
$d_check = 0;
$p_check = 0;
$x_check = 0;
$net_result = array();  //what's left when everything has been accounted for
//This data is in the same format as the data for each individual product, but the product name will be "System"

report ("<br/>All included files successfully loaded<br/><br/>",3);

function report($text,$level = 0) {
    //Add text to the debug log
    global $diagnostics, $logging_level;

    if ($level <= $logging_level) {
//        echo($text."<br/>");
//        return;
        $diagnostics .= ($text.PHP_EOL);
    }
}

function report_var($any,$level = 0) {
    //Add any variable or array to the debug log
    global $diagnostics, $logging_level;

    if ($level <= $logging_level) {
        $diagnostics .= "<pre>";
        $diagnostics .= (print_r($any,true).PHP_EOL);
        $diagnostics .= "</pre><br/>";
    }
}

function report_var2($header,$any,$level=0) {
    global $diagnostics, $logging_level;

    if ($level <= $logging_level) {
        $diagnostics .= $header."=<br/>";
        $diagnostics .= print_r($any,true);
        $diagnostics .= "<br/>";
    }
}

function outcome($result,$count) {
    //report an outcome of a compatibility test
    $str = "<b>";
    switch ($result) {
        case "OK":
            $str .= '<font color="green">OK</font>';
            break;
        case "NO":
            $str .= '<font color="red">FAIL</font>';
            break;
        case "noInfo":
            $str .= '<font color="blue">(??)</font>';
            break;
        default:
            $str .= "??";
    }
    $str .= "($count checks)</b>&nbsp;&nbsp;";
    return $str;
}

function output_report() {
    global $diagnostics;

    $diagnostics = substr($diagnostics,0,100000);    //don't let explosions break the system
    $text = $diagnostics;
    $text1 = str_replace(PHP_EOL,"<br/>",$text);
    echo ($text1);

}
