
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2022-03-08    chris.moller@evonet.com -->
	<title>Sunsafe Compatibility Checker</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2/index0.php       -->
	<meta charset="utf-8">

    <link href="dual-listbox.css" rel="stylesheet">

	<style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: white;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }

	</style>

	
</head>

<body >

<h1>Sunsafe QR-Code Generator</h1>

<p>On this page, select the JSON or QRC data file that you require to be converted into a QR-Code.</p>

<form action="phpqrcode/p2.php" method="GET" name="inputData" id="inputData">

<?php

    echo ('<select name="file" id="file" >');
    $files = scandir ('data');
    foreach ($files as $file) {
        if ((str_ends_with(strtolower($file),'.json')) or (str_ends_with(strtolower($file),'.qrc'))) {
            echo('    <option value="'.$file.'">'.$file.'</option>'.PHP_EOL);
        }
    }
    echo ('</select>');

?>


    <input name="submit" type="submit" value="Next...">


</form>




</body>
</html>

