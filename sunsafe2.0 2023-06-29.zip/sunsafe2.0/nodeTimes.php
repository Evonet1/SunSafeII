<?php

/*

CONTENTS
========

nodeTimes($ports)   - all the time points on this node

portTimes - all the time points for this port

elementTimes - all the time points for this element


*/

function elements_times($element_list) {
    //get all the times for all of the elements in the list, put them into a single array
    //sort the array in ascending order, with no duplicates
    //return the sorted array

    $unsorted = array();
    foreach ($element_list as $element) {
        $unsorted = array_merge($unsorted,get_element_times($element));
    }
    sort($unsorted);
    $result = array_unique($unsorted);
    return $result;
}



function get_element_times($element) {
    //return an array containing a list of the times that occur in time_series in this element
    $result = array();
    if (array_key_exists("lowerVoltageLimits",$element)) {
        $limit = $element["lowerVoltageLimits"];
        if (array_key_exists("timeSeries",$limit)) {
            $times = $limit["timeSeries"];
            foreach ($times as $time) {
                array_push($result,$time[0]);
            }
        }
    }
    if (array_key_exists("upperVoltageLimits",$element)) {
        $limit = $element["upperVoltageLimits"];
        if (array_key_exists("timeSeries",$limit)) {
            $times = $limit["timeSeries"];
            foreach ($times as $time) {
                array_push($result,$time[0]);
            }
        }
    }
    return $result;
}

?>
