<?php

function simplify_element($element,$time) {
    //for any parameter that is a time series, reduce or interpolate to get the values that will apply at this time
    //return a simpler element, containing no time series
    $result = array();
    foreach ($element as $key => $item) {
        $result[$key] = simplify($item,$time);
    }
    return $result;
}

function simplify_all($elements,$time) {
    //simplify all the elements in an element list
    //return a simpler element list

    report ("Time=$time",2);
    
    $result = array();
    foreach ($elements as $element) {
        array_push($result, simplify_element($element,$time));
    }
    return $result;
}

function simplify($item,$time = "INF") {
    // From some data that may be a number or an array, extract the value or range that will apply at this time.
    //  If it's a time series, interpolate if necessary to find the value, range or complex that applies at this time
    //  ... otherwise, just return $data

    //Solve trivial cases
    if ($time <= 0) {
        return null;
    }
    if (!is_array($item)) {
        return $item;
    }
    if (!array_key_exists("timeSeries",$item)) {    //unless we have something to do
        return $item;
    }
    if (!array_key_exists("steadyState",$item)) {    //unless we have something to do
        echo ("Time series must have a steady-state value");
        exit(1);
    }
    if ($time == "INF") {
        return $item["steadyState"];
    }

    $timeSeries = $item["timeSeries"];
    report_var2("TimeSeries",$timeSeries,4);
   //OK, so we have a time series, and some interpolating to do.....
    //We need to find the time entry before, and the time entry equal or after the specified time
    unset($next_time);
    $previous_time = 0;
    $previous_value = 0;
    foreach ($timeSeries as $time_entry) {        //find out which time entry is relevant, and which the previous one was
        if ($time_entry["timeLimit"] < $time) {
            $previous_time = $time_entry["timeLimit"];
            $previous_value = $time_entry["value"];
        } else {
            $next_time = $time_entry["timeLimit"];
            $next_value = $time_entry["value"];
            $interp_method = $time_entry["interpolationMethod"];
            break;
        }
    }
    if (!isset($next_time)) {   //no time entry found that exceeds the requested time
        return $item["steadyState"];
    }

    switch($interp_method) {
        case "step" : //step
            $ratio = 1;
            break;
        case "lin" : //linear interpolation
            if ((!isset($previous_time)) or (!isset($next_time))) {
                report ("First time series entry must have step interpolation");
                return null;
            }
            $ratio = ($time - $previous_time)/($next_time - $previous_time);
            break;
        case "log" :  //logarithmic interpolation
            if ((!isset($previous_time)) or (!isset($next_time))) {
                report ("First time series entry must have step interpolation");
                return null;
            }
            $ratio = (log($time) - log($previous_time))/(log($next_time) - log($previous_time));
            break;
        default :
            //should be impossible
    }

    $initial = $previous_value;
    $series = $next_value;
    $last = $initial + ($series - $initial) * $ratio;

    report("Interpolating ".$interp_method."=".$previous_time."<=".$time."<".$next_time." produced:",3);
    report_var($last,3);

    return  $last;      //the time is beyond the curve, into steady-state

}

?>