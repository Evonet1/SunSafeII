<?php

function add_paths_to_product_data (&$inProduct) {
    //If the port data does not include a "path" key, add a path comprising prodName!portName
    //Input data must be a valid SunSafe2.0 product data array (not checked)
    //We also check that ports and elements that may only be single are made into one-entry arrays
    //Actually, paths are only needed for reporting.

    $product = $inProduct;
    $prodName = $product["productName"];
    $portData = $product["port"];
    if (array_key_exists("portName",$portData)) { //if there is only one port and it isn't an array,
        $portData = [$portData];    //make it into an array
    }
    $product["port"] = $portData;
    foreach ($portData as &$port) { //pass as reference, so we can update
        if (!array_key_exists("path",$port)) {
            $name = $port["portName"];
            $port["path"] = $prodName."!".$name;
        }
        if(array_key_exists("element",$port)) { //if the port has electrical data
            $element = $port["element"];
            if (array_key_exists("voltageSource",$element)) {   //if only one element not in an array
                $element = [$element];  //make it into an array
            }
            foreach ($element as $index => &$thisElement) {
                if (!array_key_exists("path",$thisElement)) {
                    $thisElement["path"] = $prodName."!".$name."(".strval($index).")";
                }
            }
            $port["element"] = $element;
        }
    }
    $product["port"] = $portData;
    return $product;

}

?>
