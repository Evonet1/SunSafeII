<?php

//start with a system dataset with full paths added
// split out the netlist from the array of products
// for all products, 
//      create an array of product_name!port_name and port data

//for each netlist node
//  confirm that we have enough connectors of the correct type
//  if necessary
//     clear the compatible_flag and generate a report
//     if stop_on_fail set, stop

function energy_compat($system) {
    //return true or false for the electrical compatibility of a system
    global $stop_on_fail,$x_check;

    return "NoInfo"; //@@@@@@@@@@@@@@@@@@@@@@@@@@@


}


?>
