<?php

require "globals.php";

//Realistic Test data
$test_data = <<<'JSON'
{
    "$schema" : "product-schema.json",
    "shebang": "SunSafe2",
    "productName": "shs",
    "port": [{
        "serial": 1,
        "portName": "Test_",
        "element": [{
            "voltageSource": 1,
            "diode": "input",
            "impedance": {
                "type": "reactance",
                "real": [20,1000]
            },
            "currentInLimits": 5,
            "lowerVoltageLimits": {
                    "timeSeries" : [
                        {
                            "timeLimit": 2E-2,
                            "value": 0,
                            "interpolationMethod": "step"
                        },
                        {
                            "timeLimit": 0.5,
                            "value": 70,
                            "interpolationMethod": "step"
                        },
                        {
                            "timeLimit": 10,
                            "value": 80,
                            "interpolationMethod": "step"
                        }
                    ],
                    "steadyState": 90
                },
                "upperVoltageLimits": {
                    "timeSeries" : [
                        {
                            "timeLimit": 1E-4,
                            "value": 500,
                            "interpolationMethod": "step"
                        },
                        {
                            "timeLimit": 1E-3,
                            "value": 200,
                            "interpolationMethod": "log"
                        },
                        {
                            "timeLimit": 3E-3,
                            "value": 140,
                            "interpolationMethod": "log"
                        },
                        {
                            "timeLimit": 0.5,
                            "value": 120,
                            "interpolationMethod": "step"
                        }
                    ],
                    "steadyState": 110
                }
        }],
        "connector": {
            "type": "IBM_square",
            "gender": "socket",
            "fixed": null,
            "numberOfWays": 1,
            "galvanicSeparationDomain": 1
        }
    },
    {
        "portName": "Out12V",
        "serial": 2,
        "element": {
            "voltageSource": [11.5,12.5],
            "diode": "output",
            "impedance": {
                "type": "reactance",
                "real": 0.01
            },
            "currentOutLimits": 8
        },
        "connector": {
            "type": "barrel5525",
            "gender": "socket",
            "fixed": null,
            "numberOfWays": 3,
            "galvanicSeparationDomain": 1
        }
    },
    {
        "portName": "batt_port",
        "serial": 3,
        "element": {
            "voltageSource": 14.3,
            "diode": "bothways",
            "impedance": {
                "type": "constant_current",
                "value": 4
            }
        },
        "connector": {
            "type": "batt_terms",
            "gender": "socket",
            "numberOfWays": 4,
            "galvanicSeparationDomain": 1
        }
    },
    {
        "portName": "USBout",
        "serial": 4,
        "element": {
            "voltageSource": [4.8,5.1],
            "diode": "output",
            "impedance": {
                "type": "reactance",
                "real": 0.01
            },
            "currentOutLimits": 0.5
        },
        "connector": {
            "type": "USB_A",
            "gender": "socket",
            "fixed": "true",
            "numberOfWays": 2,
            "galvanicSeparationDomain": 1
        },
        "digitalProtocol": {
            "protocol": "Qualcomm QuickCharge",
            "version": "3.0",
            "role": "master"
        }
    }],
    "energyProfile": {
        "dayWh": -4,
        "nightWh": -4,
        "storageCapacity": 500,
        "passThruEfficiency": [
            {
                "inPort" : 1,
                "outPort": 2,
                "efficiency": 90
            },
            {
                "inPort" : 1,
                "outPort": 3,
                "efficiency": 90
            },
            {
                "inPort" : 3,
                "outPort": 2,
                "efficiency": 90
            },
            {
                "inPort" : 1,
                "outPort": 4,
                "efficiency": 90
            },
            {
                "inPort" : 3,
                "outPort": 4,
                "efficiency": 90
            }
        ]
    }
}
JSON;


echo("All PHP code loaded<br/>");

$shortened = longshort($test_data);
echo("<br/>SHORTENED<br/>".display_json($shortened)."<br/><br/>");

$compressed = compress_json($shortened);

echo("<br/>COMPRESSED<br/>$compressed<br/><br/>");

$restored = restore_json($compressed);

echo("<br/>RESTORED<br/>".$restored."<br/><br/>");

echo("<br/>RESTORED pretty JSON<br/>".display_json($restored)."<br/><br/>");

$lengthened = shortlong($restored);

echo("<br/>LENGTHENED<br/>".$lengthened."<br/><br/>");

echo("<br/><br/>".display_json($lengthened)."<br/><br/>");


?>