
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2022-03-08    chris.moller@evonet.com -->
	<title>Sunsafe Compatibility Checker - p2</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2/index2.php       -->
	<meta charset="utf-8">

	<style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: white;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }

	</style>

    
</head>

<body >

<h1>Sunsafe Compatibility Checker - P3</h1>

<p>This gives the result of the compatibility analysis.</p>


<?php

require "globals.php";


/*
        Load the netlist from the GET
        Validate the netlist - at least one node with two product ports
        No product port appears in more than one node
        If this test fails, abort with a message.
*/
$netlist = array(); //get the netlist
$max_ports = $_GET["max_ports"];
for ($rows = 0;$rows<$max_ports;$rows++) {
    $node0 = $_GET["node".strval($rows)];
    if (!is_array($node0) ) {
        echo("Bad netlist<br/>");
        exit(1);
    }
    switch (count($node0)) {
        case 0:
            break;
        case 1:
           echo("Net node $row must have at least two connections!<br/>");
            exit(1);
        default:
            $node = array();
            $node_good = false;
            foreach ($node0 as $node_element) {
                if ($node_element != "") {
                    $node_good = true;
                    array_push($node,$node_element);
                }
            }
            if ($node_good) {
                array_push($netlist,$node);
            }
            break;
    }
}

report("Netlist has ".count($netlist)." node(s)",2);
//    echo("<br/>Netlist<br/>");
//    print_r($netlist);

//Now load the referenced data into $php_data[$products]
$php_data = array();
$files = $_GET["files"];
foreach ($files as $file) {
    $data = file_get_contents("data/".$file);
    if (str_ends_with(strtolower($file),'.qrc')) {
        $shortdata = restore_json($data);
        $data = shortlong($shortdata);
    }
    $p_data = json_decode($data,true);
    if (is_null($p_data)) {
        echo "File $file is not a valid JSON file".PHP_EOL;
        exit(1);
    }
    if (!array_key_exists("productName",$p_data)) {
        echo("Missing product name in data for $file");
        exit(1);
    }
    $q_data = add_paths_to_product_data($p_data);
//    echo("<br/>q_data<br/>");
//    print_r($q_data);

    $prodName = $q_data["productName"];
    $php_data[$prodName] = $q_data;

    report ("File '$file' read successfully",3);

}
report (count($php_data)." files read",3);
//    echo("<br/>php_data<br/>");
//    print_r($php_data);

//use $p_data for the last file read to populate $net_result
if (array_key_exists("schema",$p_data)){
    $net_result["schema"] = $p_data["schema"];
}
$net_result["productName"] = "System";
//we need to add ports here, with all their data.  At the end, if there are no connections left, we can delete them.



//Now do electrical, mechanical and digital compatibility testing, one node at a time
foreach ($netlist as $nodelist) {
    $portlist = implode(", ",$nodelist); //just for reporting

    $e_result = elect_compat($nodelist,$php_data);

    $c_result = conn_compat($nodelist,$php_data);

    $d_result = earth_compat($nodelist,$php_data);

    $p_result = pcol_compat($nodelist,$php_data);

    $report_str = ("<b>Node </b><i>$portlist</i>:<br/>");
    $report_str .= "Electrical: ".outcome($e_result,$e_check);
    $report_str .= "Connectors: ".outcome($c_result,$c_check);
    $report_str .= "Earthing: ".outcome($d_result,$d_check);
    $report_str .= "Protocols: ".outcome($p_result,$p_check);
    report($report_str);

}

$x_result = energy_compat($netlist,$php_data);
//we need to decide how we're going to report this - remember it's only an estimate!



output_report();

?>




</body>
</html>
