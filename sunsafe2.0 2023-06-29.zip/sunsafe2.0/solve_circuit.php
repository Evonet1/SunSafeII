<?php


//*****************************************************************************


function solve_circuit($elements) {
    //The input parameter must be an array of simple elements - no ranges or time-series
    // The value returned is an array [terminal_voltage,element_currents[]]
    // unless something failed, in which case, return FALSE, and add a diagnostic message

    global $e_check;

    $e_check++;
    $els = count($elements);        //populate the input arrays
    report ("Analysing $els elements",3);
    for($el = 0; $el < $els; $el++) { //extract each element
        $element = $elements[$el];
        $Vs[$el] = $element["voltageSource"];
        $D[$el] = $element["diode"];
        $impedance = $element["impedance"];
//print_r($impedance);	//@@@@@@@@@@@@@@@@@@@@@@@@@
        $Z[$el] = $impedance["type"];   //type of impedance
        $X[$el] = 1;
        if (array_key_exists("value",$impedance)) {
            $X[$el] = $impedance["value"];   //value of impedance 
        }
        if (is_array($X[$el])) {
            $X[$el] = $X[$el]["real"];  //we need to get cleverer about this!
        }
        $port_name[$el] = substr($element["path"],0,-3);  //for reporting
    }

    //Hypothesise a terminal voltage, calculate currents iteratively

    //calculate a sensible starting voltage - the average of all the 'out' voltages
    $highest_source = 0;   //find highest source voltage
    $min_source_resistance = 1E6;    //start at a megohm
    for($el = 0; $el < $els; $el++) { //extract each element
        if ($D[$el] != "in") { 
            if ($Vs[$el] > $highest_source) {
                $highest_source = $Vs[$el];
            }
            if (($Z[$el] == "reactance") and ($X[$el] < $min_source_resistance)) {
                $min_source_resistance = $X[$el];       //need to change this complex values
            }
            if ($Z[$el] == "constant_current") {   //constant current source
                $cc_res = $Vs[$el]/$X[$el];
                if ($cc_res < $min_source_resistance) {
                    $min_source_resistance = $cc_res;
                }
            }
        }
    }

    report ("Highest source  = ".$highest_source."V",3);
    report ("Min source resistance  = ".$min_source_resistance."&#8486;",3);

    $total_volts = 0;   //find average of all voltages that are part of the story
    $active_elements = 0;
    for($el = 0; $el < $els; $el++) { //extract each element
        if ($Vs[$el] <= $highest_source) {   //if this element can be active in this circuit
            $total_volts += $Vs[$el];
            $active_elements++;
        }
    }
    $average_volts = $total_volts/$active_elements;
    report ("Average volts  = ".$average_volts."V over $active_elements elements",3);

    //We want the interation to continue until the weakest current is accurate to about 1%
    //Assume the weakest current will be (average_volts)/(highest impedance) or
    //  the lowest constant current, or the lowest power/average volts
    $lowest_current = 1e3;     // start at a kiloamp!
    for($el = 0; $el < $els; $el++) { //extract each element
        if ($Vs[$el] <= $highest_source) {   //if this element can be active in this circuit
            switch ($Z[$el]) {
                case "reactance":   //apply Ohm's Law
                    if ($average_volts/$X[$el] < $lowest_current) {
                        $lowest_current = $average_volts/$X[$el];
                    }
                    break;
                case "constant_current" :
                    if ($X[$el] < $lowest_current) {
                        $lowest_current = $X[$el];
                    }
                    break;
                case "constant_power" :
                    if (($X[$el]/$average_volts) < $lowest_current) {
              //There are no dependencies           $lowest_current = $X[$el]/$average_volts;
                    }
                    break;
                default:
                    return false;   //this should never happen
            }
        } 
    }
     
    //Now set a reasonable starting voltage
    $V = $average_volts;
    $iteration_current = $lowest_current/100;   //solution to 1% accuracy 
    if ($iteration_current < 1E-4) {    //100uA
        $iteration_current = 1E-4;
    }
    $iterate_limit = 200;
    $report_s =  ("Starting values:<br/>V = ".$V."V, Iteration limit = ".
        $iteration_current."A, Lowest impedance = ".$min_source_resistance."&#8486;");
    report ($report_s,4);
    //Solve the circuit
    $iterate = 0;
    $currents = array();
    do {
        $total_current = 0; //Kirchoff says we must get total current to zero
        for($el = 0; $el < $els; $el++) { //extract each element
            if (
            (($D[$el] != 'in') and ($Vs[$el] > $V)) or      //power out
            (($D[$el] != 'out') and ($Vs[$el] < $V))) {     //power in
                switch ($Z[$el]) {
                    case "reactance":   //apply Ohm's Law
                        $current = (($Vs[$el] - $V)/($X[$el])); //we will need to change for complex
                        break;
                    case "constant_current" :
                        $current = $X[$el];
                        if ($Vs[$el] < $V) {
                            $current = -$current;
                        } 
                        break;
                    case "constant_power" :
                        $current = $X[$el]/$V;
                        if ($Vs[$el] < $V) {
                            $current = -$current;
                        } else {
                            $current = 0;
                        }
                        break;  

                    default:
                        return false;   //this should never happen
                }
                $currents[$el] = $current;  //for returning the result
                $total_current += $current; //Kirchoff says total_current must be zero
            } else {
                $currents[$el] = 0; //no current if diode reverse-biased
            }
        } 
        report ("Solution= Voltage: $V, Total_current: $total_current",5);
        //$total_current is the error.  If total current is negative, then V is too high
        $V = $V + $total_current * $min_source_resistance/2;    //@@@ We need to get this right @@@ 

        if ((++$iterate)  >= $iterate_limit) {
            report ("No circuit solution found after $iterate iterations");
            return null;
        }; 
    } while (abs($total_current) > $iteration_current) ;

    report ("Solution ($iterate iterations) = Voltage: ".number_format($V,4).
       "V, Total_current: ".number_format($total_current,4)."A",2);
    for($el = 0; $el < $els; $el++) { //display the result
        report ($port_name[$el].": I = ".number_format($currents[$el],4)."A, P = ".number_format($currents[$el]*$V,4)."W",2); 
    } 
    return [$V,$currents]; 
}


?>
