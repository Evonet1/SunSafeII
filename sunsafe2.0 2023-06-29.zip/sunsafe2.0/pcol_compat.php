<?php


function pcol_compat($nodelist,$php_data) {
    //return "OK", "no" or "noInfo" for the protocol compatibility of a system
    //nodelist is a list of the ports that are connected together
    global $stop_on_fail,$p_check,$logging_level;

    $compatibility = "OK";

    //To assess protocol compatibility, we need an array $protocolData for all connected ports of:
    // port protocol data, port_path
    $protocolsToTest = false;
    $protocolData = array();
    foreach ($nodelist as $port) {
        $reference = explode("!",$port);    //separate out product and port
        if (count($reference) < 2) {
            echo("Faulty port reference <i>$port</i> in netlist");
            return("dataError");
        }
        $productName = $reference[0];
        $portName = $reference[1];
        if (!array_key_exists($productName,$php_data)) {
            echo("Nodelist contains unknown product $productName");
            return("dataError");
        }
        $productData = $php_data[$productName];
        $portData = $productData["port"];       //if there isn't a port key, we'll have trapped it before
        //This is now the port data for all the ports on a particular product
        if (array_key_exists("portName",$portData)) { //if there is only one port and it isn't an array,
            $portData = [$portData];    //make it into an array
        }
        foreach ($portData as $possPort) {      //check all the ports for this product
            //Find the port referenced in the netlist
            if ($possPort["portName"] == $portName) {   //this is the port we need protocol data for
                $myProtocol = array();
                if (!array_key_exists("standardProtocol",$possPort)){  //it's a dumb load
                    $myProtocol["standardProtocol"] = null;
                } else {
                    $myProtocol["standardProtocol"] = $possPort["standardProtocol"];
                    if (($myProtocol  == "none") or 
                      (is_array($myProtocol) and array_key_exists("protocol",$myProtocol) and $myProtocol["protocol"]== "none")) {
                        //if every connected port is defined as having no protocol, that passes!
                    } else {
                        $p_check++;
                        $protocolsToTest = true;
                    }
                }
                $myProtocol["path"] = $possPort["path"];
                array_push($protocolData,$myProtocol);
                break;
            }
        }
    }

    if (!$protocolsToTest) {
        $p_check = 1;
        $compatibility = "OK";
        return $compatibility;    //all ports are dumb
    }

    //In $protocolData, we now have an array of all relevant protocol data for the relevant ports.
    //  Each item is a keyed array ["standardProtocol","path"]
    
    report("Checking that all smart ports are using the same protocol system",4);
    $standard = "";
    $version = "";
    foreach ($protocolData as $portProtocol) { 
        $thisPortPcol = $portProtocol["standardProtocol"];
        $thisPortPath = $portProtocol["path"];
        if (!is_null($thisPortPcol)) {   //unless we have a dumb load
            $pcol = $thisPortPcol["protocol"];  //check that all ports have the same protocol string
            if ($standard == "") {  //first protocol found
                $standard = $pcol;
            } else {
                if ($pcol != $standard) {   //subsequent have to match
                    report("Smart ports adhere to different protocol standards (<i>$pcol != $standard</i>)",2);
                    $compatibility = "NO";
                    if ($stop_on_fail) {
                        return $compatibility;   
                    }
                }
            }
            $p_check++;
        }
    }
    report("All smart ports are using the same protocol system",4);
    
    report("Finding out what <i>$standard</i> requires",4);
    $required = "";
    $requiredComms = "";
    foreach ($protocolData as $portProtocol) { 
        if (!is_null($portProtocol["standardProtocol"])) {   //we don't have a dumb load
            $thisPortPcol = $portProtocol["standardProtocol"];
            if (array_key_exists("requiredRoles",$thisPortPcol)) {
                $roles = $thisPortPcol["requiredRoles"];
                if ($required == "") {
                    $required = $roles;
                } else {
                    if ($roles !== $required) {  //array compare! (must be in the same order)
                        report("Ports disagree on the roles the protocol requires - this is likely to be an editing problem",2);
                        $compatibility = "NO";
                        if ($stop_on_fail) {
                            return $compatibility;           $p_check++;
                        }
                    }
                }
                $p_check++;
            } 
            if (array_key_exists("requiredComms",$thisPortPcol)) {
                $comms = $thisPortPcol["requiredComms"];
                if ($requiredComms == "") {
                    $requiredComms = $comms;
                } else {
                    if ($comms !== $requiredComms) {  //array compare! (must be in the same order)
                        report("Ports disagree on the communications the protocol requires - this is likely to be an editing problem",2);
                        $compatibility = "NO";
                        if ($stop_on_fail) {
                            return $compatibility;           $p_check++;
                        }
                    }
                }
                $p_check++;
            }             
        }
    }
    if ($required == "") {
        report("<b>WARNING:</b> Protocol role checking skipped",3);
    } else {        print_r($requiredComms);
        if (find_type($system) != "system") {
            report ("Bad input data to conn_compat - not a system");
            return "dataError";   if (find_type($system) != "system") {
                report ("Bad input data to conn_compat - not a system");
                return "dataError";
            }
        
        }
    
        report("Tally up all roles that are present",4);
        //We can use $required, because we now know it's the same for all the ports - it is an array of [role, minOccurs, maxOccurs]
        //If role is null (ie a dumb load), then minOccurs, maxOccurs are in Watts
        //If maxOccurs == -1, then maxOccurs == Unlimited

        foreach ($required as &$addTally) {
            array_push($addTally,0);    //this will be $protocolData[3]
        }

        $dumbFlag = false;  //are dumb loads supported?
        foreach ($required as $dumbRole) {
            if ($dumbRole[0] == "dumb") {
                $dumbFlag = true;
            }
        }

        //it would be good if we could make it so that the requiredRoles lists didn't all have to be in the same order
        foreach ($protocolData as $portProtocol) { 
            if (!is_null($portProtocol["standardProtocol"])) {   //we don't have a dumb load
                $thisPortPcol = $portProtocol["standardProtocol"];
                $thisPortPath = $portProtocol["path"];
                $myRoles = $thisPortPcol["myRoles"];
                if (!is_array($myRoles)){
                    $myRoles = [$myRoles];    //make into an array
                }
                foreach ($myRoles as $myRole) {
                    if (!array_key_exists($myRole,$required)) {
                        report ("myRole $myRole not found in requiredRoles",2);
                        $compatibility = "NO";
                        if ($stop_on_fail) {
                            return $compatibility;   
                        }
                    }
                    $required[$myRole][3]++;
                }
            } else {    //dumb load
                if (!$dumbFlag) {
                    report("Dumb loads are not supported under this protocol",2);
                    $compatibility = "NO";
                    if ($stop_on_fail) {  
                        return $compatibility;   
                    }
                }
                foreach ($required as &$requiredRole) {
                    if ($requiredRole[0] == "dumb"){
                        $requiredRole[3]++;      //this would better be the total power of the dumb loads - how?
                    }
                }        $p_check++;
            }
        }

        foreach ($required as $x) { //just report
            report($x[0].": ".$x[3],4);
        }

        report("Now check the tally is within permissible limits",4);
        foreach ($required as $roleLimits) { //check each counter
            if (($roleLimits[3] < $roleLimits[1]) or (($roleLimits[2] > 0) and ($roleLimits[3] > $roleLimits[2]))) {
                report("Too few/many ports with role <i>".$roleLimits[0]."</i> (".
                $roleLimits[1]." < ".$roleLimits[3]." < ".$roleLimits[2].")",2);
                $compatibility = "NO";
                if ($stop_on_fail) {
                    return $compatibility;   
                }
            }
            $p_check++;
        }
    }
    if ($compatibility == "OK") {
        report("All roles are within permissible limits",4);
    }

    //We've passed the required roles test, but are implemented versions such that those that need to
    //  communicate share a common protocol version?
    report("Testing whether required functions can communicate",4);
    if ($requiredComms != "") {
        if ((is_array($requiredComms)) and (!is_array($requiredComms[0]))) {
            $requiredComms = [$requiredComms];
        }
        foreach ($protocolData as $portProtocol) { 
            if (!is_null($portProtocol["standardProtocol"])) {   //we don't have a dumb load
                $thisPortPcol = $portProtocol["standardProtocol"];
                $thisPortPath = $portProtocol["path"];
                if (array_key_exists("implementedVersions",$thisPortPcol)) {
                    $vers = $thisPortPcol["implementedVersions"];
                    $myRoles = $thisPortPcol["myRoles"];
                    if (!is_array($myRoles)){     //force into an array
                        $myRoles = [$myRoles];
                    }
                    foreach ($myRoles as $myRole) {  //for each of my roles
                        //now check what this role needs to communicate with
                        foreach ($requiredComms as $commEntry) {
                            if ($commEntry[0] == $myRole) {
                                $thisRoleSorted = false;    //it has an entry, so it must be satisifed
                                $soughtRole = $commEntry[1]; //this is the role we need to communicate with
                                foreach ($protocolData as $otherProtocol) { //try every other connected port
                                    if ($otherProtocol["path"] != $thisPortPath) { //skip ourselves
                                        $otherPortPcol = $otherProtocol["standardProtocol"];
                                        report("Checking comms between $thisPortPath and ".$otherProtocol["path"],4);
                                        if (!is_null($otherPortPcol)) {     //unless dumb
                                            $otherRoles = $otherPortPcol["myRoles"];
                                            if (!is_array($otherRoles)) { $otherRoles = [$otherRoles]; }
                                            foreach ($otherRoles as $otherRole) {
                                                report("Checking $otherRole against $soughtRole",4);
                                                if ($otherRole == $soughtRole) {    //we've found someone we have to talk to
                                                    if (array_key_exists("implementedVersions",$otherPortPcol)) {
                                                        $vers2 = $otherPortPcol["implementedVersions"];
                                                        $p_check++;
                                                        report("Checking comms between $thisPortPath($soughtRole) and ".$otherProtocol["path"]."($otherRole)",4);
                                                        if (!checkVersionInCommon($vers,$vers2)) {
                                                            $compatibility = "NO";
                                                            if ($stop_on_fail) {
                                                                return $compatibility;   
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        report("<b>WARNING:</b> communications checking skipped for <i>$thisPortPath</i>",2);
    }

    return $compatibility;
}

function checkVersionInCommon($versions1,$versions2) {
    // compare two sets of version information (which may be a string or an array of strings)
    // and if they have any string in common, return TRUE

    $v1 = $versions1;
    $v2 = $versions2;
    if (!is_array($v1)) {   //force both parameters to be arrays
        $v1 = [$v1];
    }
    if (!is_array($v2)) {
        $v2 = [$v2];
    }
    foreach ($v1 as $va) {  //try every combination
        foreach ($v2 as $vb) {
            if ($va == $vb) {
                return true;
            }
        }
    }
    return false;
}

?>
