
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2022-03-08    chris.moller@evonet.com -->
	<title>Sunsafe Compatibility Checker - p2</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2/index0.php       -->
	<meta charset="utf-8">

    <link href="dual-listbox.css" rel="stylesheet">

	<style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: white;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }

	</style>

    
</head>

<body >

<?php

$html_out = <<<HTML

<h1>Sunsafe Compatibility Checker</h1>

<p>On this page, create the netlist that specifies which ports are connected to which node.</p>

<form action="index2.php" method="GET" name="inputData" id="inputData">

HTML;

    require "globals.php";

    $php_data = array();
    $files = $_GET["files"];
    foreach ($files as $file) {
        $data = file_get_contents("data/".$file);
        if (str_ends_with(strtolower($file),'.qrc')) {
            $shortdata = restore_json($data);
            $data = shortlong($shortdata);
        }
        $p_data = json_decode($data,true);
        if (is_null($p_data)) {
            echo "File $file is not a valid JSON file".PHP_EOL;
            exit(1);
        }
        if (!array_key_exists('productName',$p_data)) {
            echo ("Product name missing from data in file $file");
            exit(1);
        }
        if ((!array_key_exists('port',$p_data)) or (!is_array($p_data['port']))) {
            echo("Port data missing in file $file");
            exit(1);
        }
        if (!(array_key_exists(0,$p_data['port']) and (array_key_exists('portName',$p_data['port'][0]))) and 
          (!array_key_exists('portName',$p_data['port']))) {
            echo("portName missing in file $file");
            exit(1);
        } 

        //Test if the data contains unrecognised keywords
        $checkKeywords = longshort($data);
        preg_match_all('/(\"[A-Za-z0-9][A-Za-z0-9_+. \-]+"):/',$checkKeywords,$matches);
        if (count($matches)> 0) {
            $match1 = $matches[1];
            if (count($match1) > 0 ) {
                $unknown = "WARNING: File <i>$file</i> contains keyword(s) <i>";
                foreach ($match1 as $match) {
                    $unknown .= ($match.", ");
                }
                report ($unknown."</i> which are unrecognised by this version of the software, and will be ignored when assessing compatibility",1);
            }
        }
        array_push($php_data,$p_data);
        $html_out .=('<input type="hidden" name="files[]" id="files[]" value="'.$file.'"/>');

    }

    //Check structure of the data

    $num_prods = count($php_data);
    if ($num_prods == 1) {
        echo ("You must provide at least two products to make a system!");
        exit(1);
    }
    report("$num_prods products loaded<br/>".PHP_EOL,1);
        
    $html_out .= ('<table border="1"><tr><th width="50">Node</th>'.PHP_EOL);
    $max_ports = 0;
    foreach($php_data as $index => $product) {  //set up header for table
        $prod_name[$index] = $product['productName'];   //product name
        $port1 = $product['port'];   //all port data for this product
        if (!array_key_exists(0,$port1)) {  //we are seeing actual port data, not an array of ports
            $port1 = [$port1];  //make a single port into an array
        }
        if (count($port1) > $max_ports) {
            $max_ports = count($port1);
        }
        $port_data[$index] = $port1;   //all port data for this product
        $html_out .= ('<th width="120">'.$prod_name[$index].'</th>'.PHP_EOL);
    }        
    $html_out .= ('</tr>'.PHP_EOL); //end header row

    for ($rows = 0;$rows<$max_ports;$rows++) {   //allow for six nodes for now
        $html_out .= ('<tr>');
        $html_out .=  ('<td>'.strval($rows+1).'</td>');
        for ($cols = 0 ;$cols < $num_prods; $cols++) {
            $html_out .= ('<td><select name="node'.strval($rows).'[]">'.PHP_EOL);
            $html_out .=  ('<option value=""></option>'.PHP_EOL);   //default to a blank cell
            $this_port = $port_data[$cols];     //all port data for this product
            foreach ($this_port as $port) {     //for all ports on this product
                $port_name = $port['portName'];
                $html_out .=  ('<option value="'.$prod_name[$cols].'!'.$port_name.'">'.$port_name.'</option>'.PHP_EOL);
            }
            $html_out .= ('</select></td>');
        }
        $html_out .=  ('</tr>'.PHP_EOL);
    }
    $html_out .=  ('</table>'.PHP_EOL);
    $html_out .= ('<input type="hidden" id="max_ports" name="max_ports" value= "'.$max_ports.'">');

    output_report();

    echo ($html_out);  

?>

    <input name="submit2" type="submit" value="Next...">


</form>


</body>
</html>

