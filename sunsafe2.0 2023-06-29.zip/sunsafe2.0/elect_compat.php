<?php

//start with a system dataset with full paths added
// split out the netlist from the array of products
// for all products, 
//      create an array of product_name!port_name and port data

//for each netlist node
//  confirm that we have data for the specified port
//  assemble an element list (and a list of element names for diagnostic purposes)
//  create a times list
//  initialise a counter[elements] for de-ranging
//  set compatible_flag=true
//  for each time in the tim(es list
//      for each counter value
//          solve the circuit
//          check the limits
//          if necessary
//              clear the compatible_flag and generate a report
//              if stop_on_fail set, stop

function elect_compat($nodelist, $products) {
    //return true or false for the electrical compatibility of a single node
    //including if one of the products gets knocked out for any reason

    switch ($result = elect_compat1($nodelist, $products)) {
        case "no":  //failed electrical compatibility with all products present
        case "zero":    //no current will flow
        case "noInfo":  //insufficient information to assess electrical compatibility
        case "dataError":
            return $result;
            break;
    }
    // system is compatible - but will it still be if one product is knocked out?
    if (count($nodelist) > 2) {
        foreach($nodelist as $portToRemove) {
            $nodelist1 = $nodelist;
            report("Knocking out $portToRemove, checking still compatible",4);
            unset($nodelist1,$portToRemove);
            $result = elect_compat1($nodelist, $products);
            if ($result == "no") {  //note that a result of "zero" is acceptable in this case
                report("WARNING: If $portToRemove disappears, the system cannot operate without it");
            }                        report("Checking comms for $thisPortPath",4);

        }
        return "OK";
    }
}

function elect_compat1($nodeList, $products) {
    //return true or false for the electrical compatibility of a single node
    global $stop_on_fail, $e_check;

    //build a complete list of all the relevant elements and time points
    $elementList = array();
    $timePoints =  array();
    foreach ($nodeList as $portPath) {
        $portDetail = explode("!",$portPath);
        $productName = $portDetail[0];
        $portName = $portDetail[1];
        if (!array_key_exists($productName,$products)) {
            echo("Product $productName not found");
            return("dataError");
        }
        $product = $products[$productName];
        if (!array_key_exists("port",$product)) {
            echo ("No port info found for product $productName");
            return("dataError");
        }
        $ports = $product["port"];
        if (array_key_exists("portName",$ports)) { //if not an array, make into one
            $ports = [$ports];
        }
        $port = null;
        foreach ($ports as $port1) {
            if (!array_key_exists("portName",$port1)) {
                echo("No portName found in ports for $productName");
                return("dataError");
            }
            if ($port1["portName"] == $portName) {
                $port = $port1;
                break;
            }
        }
        if (is_null($port)) {
            echo("<i>$portName</i> not found in ports for <i>$productName</i>");
            return("dataError");

        }
        if (!array_key_exists("element",$port)) {
            return "noInfo";
        }
        $elements = $port["element"];
        if (array_key_exists("voltageSource",$elements)) {
            $elements = [$elements];    //if not an array, make it into one
        }
        report ("Adding ".count($elements)." element(s) at port $portPath to element list",4);
        $elementList = array_merge($elementList,$elements);

        //now build the time point list for voltage limits at this port
        if (array_key_exists("lowerVoltageLimits",$port)) {
            $limit = $port["lowerVoltageLimits"];
            if ((is_array($limit) and (array_key_exists("timeSeries",$limit)))) {
                $times = $limit["timeSeries"];
                foreach ($times as $time) {
                    array_push($timePoints,$time["timeLimit"]);
                }
            }
        }
        if (array_key_exists("upperVoltageLimits",$port)) {
            $limit = $port["upperVoltageLimits"];
            if ((is_array($limit)) and (array_key_exists("timeSeries",$limit))) {
                $times = $limit["timeSeries"];
                foreach ($times as $time) {
                    array_push($timePoints,$time["timeLimit"]);
                }
            }
        }
    }
    //now add in the element time points
    foreach ($elementList as $element) {
        $timePoints = array_merge($timePoints,get_element_times($element));
    }
    sort($timePoints);
    $timePoints = array_unique($timePoints);
    report("Checking at times ".implode(", ",$timePoints),4);

    report_var2 ("ElementList",$elementList,4);
    report_var2("TimePoints",$timePoints,4); 

    //we now have a complete list of relevant elements and time points, but each element may have several voltageSource options

    initialise_counter($elementList);  // initialise the radix of the relevant digit of the counter

    //run the counter
    while (($selectors = get_counter()) != 0) {     //      for each counter value
        $e_check++;
        report_var2("Selectors",$selectors,4);
        // simplify the elements
        $optElements = array();
        foreach ($elementList as $index => $element)  {
            $element1 = $element;
            $vSource = $element1["voltageSource"];
            if (is_array($vSource)) {
                $vSource = $vSource[$selectors[$index]];    //choose the right single value
                $element1["voltageSource"] = $vSource;
            }
            array_push($optElements,$element1);
        }

        report_var2("OptElements",$optElements,4);
        //now optElements are elements with a single voltageSource value, but still some time series
        foreach ($timePoints as $timePoint) {       // run all the time points
            $simpleElements = simplify_all($optElements,$timePoint); //fix timed values

            report_var2("SimpleElements",$simpleElements,4);

            $VI = solve_circuit($simpleElements);


            //Now we need to test limits @@@@@@@@@@@@@@@@  08Nov2022 @@@@@@@@@@@@@@@

//            echo("At time $timePoint the solution was:<br/>");
//            print_r($VI);
        } 
    }   //while checking every voltageSource value

/*    

If the Any flag is absent, we need the circuit to solve for every voltageSource value for this element
 - if any circuit doesn't solve, it's a FAIL
If the Any flag is present, we are looking for any success - report the voltageSource values for all arrayed voltageSources


*/

    return "noInfo"; //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

/* 
        $alternatives = find_variant_count($node_elements);

        $pass = true;

        foreach ($times as $time) { //  for each time in the times list
            report("============ Time=$time ==============",3);
            $timed_elements = simplify_all($node_elements,$time);
            initialise_counter($alternatives);  //  initialise a counter[elements] for de-ranging

            while (($selectors = get_counter()) != 0) {     //      for each counter value
                $e_check++;
                $simple_elements = derange_all($timed_elements,$selectors);
                $voltamps = solve_circuit($simple_elements);    //          solve the circuit
                if (!is_null($voltamps)) {
                    report_var($voltamps,3);
                    $result = test_all_limits($voltamps,$simple_elements,$selectors,$index,$time);  //          check the limits
                    if (!$result) { //          if failed
                        $pass = "no";
                        if ($stop_on_fail) {
                            return "no";    //              if stop_on_fail set, stop
                        }
                    }
                } else {
                    return "no";    //no solution found
                }
            }
            if (($pass == "no") and ($time == "INF")) {
                report("Statdy-state failed, so further time analysis aborted",2);
                break;
            }
        }

        report ("Node elements = ",3);
        report_var($node_elements,3);

        if ($pass != "no") {
            report("At node ".$index.", all connections ".$port_list." are electrically compatible");
        }
    }
    return $pass; */
}
/*
function test_all_limits($voltamps, $simple_elements,$alternatives,$index,$time = "INF") {
    //check whether the voltamps values found are within limits for all elements
    //return true or false according t
o whether within limits
    //time and alternatives are only used for reporting
    global $stop_on_fail,$e_check;

    $pass = true;
    $volts = $voltamps[0];
    $currents = $voltamps[1];
    $range_options = 1; //just get a single overall number for which range is being assessed (for reporting only)
//    echo("<br/>Alternatives=");
//    var_dump ($alternatives);
    foreach ($alternatives as $alternative) {
        $range_options *= ($alternative+1);
    }
    foreach ($simple_elements as $index => $element) {
//        report ("Element=");
//        report_var($element);
        $current_limit = $element[3];
        $volt_range = $element[4];
        if (!is_null($current_limit)) { //if current matters....
            $e_check++;
            $current_limit = abs($current_limit);
            $actual_current = abs($currents[$index]);
            if ($current_limit < $actual_current) {
                report ("At node $index at time ".$time."s with range options ".$range_options.", element current = ".$actual_current."A",1);
                report (" which exceeds permitted (".$current_limit."A) for element '".$element[5]."'",1);
                $pass = false;
            }
        } 
        if (!is_null($volt_range)) {    //if voltage matters....
            $e_check++;
            $min_volts = $volt_range[0];
            $max_volts = $volt_range[1];
            if (($volts < $min_volts) or ($volts > $max_volts)) {
                report ("At node $index at time ".$time."s with range options ".$range_options.", terminal voltage = ".$volts."V",1);
                report (" which is outside permitted range (".$min_volts."V...".$max_volts."V) for element '".$element[5]."'",1);
                $pass = false;
            }
        }
        if ((!$pass) and ($stop_on_fail)) {
            return false;
        }

    }
    return $pass;
}
*/
?>
