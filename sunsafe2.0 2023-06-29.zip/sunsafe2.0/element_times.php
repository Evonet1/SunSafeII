<?php

/*

CONTENTS
========

element_times($element)
-----------------
Returns an array of all the time points contained in the element
There may be duplicates, and they will not be in order.

*/



function get_element_times($element) {
    //return an array containing a list of the times that occur in time_series in this element
    $result = array();
    if (array_key_exists("currentLimits",$element)) {
        $limit = $element["currentLimits"];
        if ((is_array($limit)) and (array_key_exists("timeSeries",$limit))) {
            $times = $limit["timeSeries"];
            foreach ($times as $time) {
                array_push($result,$time["timeLimit"]);
            }
        }
    }
    if (array_key_exists("currentInLimits",$element)) {
        $limit = $element["currentInLimits"];
        if ((is_array($limit)) and (array_key_exists("timeSeries",$limit))) {
            $times = $limit["timeSeries"];
            foreach ($times as $time) {
                array_push($result,$time["timeLimit"]);
            }
        }
    }
    if (array_key_exists("currentOutLimits",$element)) {
        $limit = $element["currentOutLimits"];
        if ((is_array($limit)) and (array_key_exists("timeSeries",$limit))) {
            $times = $limit["timeSeries"];
            foreach ($times as $time) {
                array_push($result,$time["timeLimit"]);
            }
        }
    }

    return $result;
}

?>
