<?php

//The following routines are applicable to ANY JSON files (not just Sunsafe)

function indent_json ($json_data) {
    //With any valid JSON file, add newlines and indentation
    //Returns null if the data is not valid JSON
    //This is the opposite of compact_json()
	if (!is_string($json_data)) {
		return "JSON is not a string";
	}
    $php_obj = json_decode($json_data);
	if (is_null($php_obj)) {
		return "Illegal JSON format";
	}
    $json_obj = json_encode($php_obj, JSON_PRETTY_PRINT);
    return $json_obj;
}

function display_json($json_data) {
	// Prepare JSON file for a web page
	$js1 = indent_json($json_data);
	return ('<pre>'.$js1.'</pre>');
}

function compact_json ($json_data) {
    /*With any valid JSON file:
        Escape any control chars in strings to their unicode equivalents (so we can remove double-quotes)
        Remove all whitespace
        The result is still valid JSON - just smaller */

        //The following characters are allowed in a JSON string, but also form part of
        //  the essential JSON syntax
        $syntax_chars = array("[","]","{","}",":",",");
        //These are replaced with their \u00xx equivalents
        $js1 = str_replace('\\"','\\u0022',$json_data);   //deal with any escaped " in a string
        //Note that this could cause an issue with a string ending \\" - this isn't easily fixed
        $elements = explode('"',$js1);
        $result = "";
        $string_flag = false;   //first will always be control char in valid JSON
        foreach ($elements as $element) {
            $this_element = $element;
            if ($string_flag) {     //we are in a string

                foreach ($syntax_chars as $syntax_char) {      //replace with safe equivalent
                    $unicode = "\\u00".bin2hex($syntax_char);
                    $this_element = str_replace($syntax_char,$unicode,$this_element);
                }   
                $string_flag = false;
            } else {    //this is a series of JSON syntax chars, so leave intact
                $this_element = preg_replace('/\s/','',$this_element);  //remove any whitespace in syntax
                $string_flag = true;
            }
            $result .= ('"'.$this_element);   //build result string, putting back doubleqotes.   
        }
        $result = ltrim($result,'"');
        //At this point, we have escaped anything that needed escaping, and removed all whitespace not in values

        return ($result);
}


/******************************************************************************/

// The following routines are specific to SunSafe JSON files

/******************************************************************************/


$schema = "product-schema.json";  //change this, if you make any changes to the format of the data


/******************************************************************************/

function compress_json ($json_string) {
    /* This turns JSON into a shorter ASCII string, without the JSON punctuation.  It only works
    correctly if doublequotes and other control characters in string literals have been replaced
    with escape codes. Whilst this is NOT valid JSON, valid JSON can be easily recovered from it. */

    global $schema;

    $result = compact_json($json_string);  //escape any control characters, remove whitespace
    //ensure all numeric values are signed (NB positive signed values are not valid JSON)
    $pattern = '/:([0-9])/';
    $result = preg_replace($pattern,':+$1',$result);

    //lastly, remove all double-quotes and nulls
    $result = str_replace('"','',$result);
    $result = str_replace('null','',$result);
    $result = $schema.$result;

    return ($result);
}
    


/******************************************************************************/

function restore_json ($qr_string) {

    //  Undo the compression done by compress_json():
    //output is valid JSON

    global $schema;

    if (substr($qr_string,0,strlen($schema)) != $schema) {
        return "Unrecognised QR-code format";
    } else {
        $js1 = substr($qr_string,strlen($schema));    //remove schema
    }
     //restore all the double-quotes
    $js2 = trim(preg_replace("/[\\[\\]\\{\\}:,]+/",'"$0"',$js1),'"');
    //Any sequence of syntax chars has " added before and after.
    //Trim removes the initial and final "
    $js3 = preg_replace ("/,([,\\]\\}])/",',null'.'$1',$js2);   //restore nulls
    $js4 = preg_replace ("/([\\[\\{:]),/",'$1'.'null,',$js3);
 
    // Remove the double-quotes just added around numeric values
    $pattern = '/"([+\-]?[0-9]+(\.[0-9]+)?(E[+\-]?[0-9]+)?)"/';
    $js5 = preg_replace($pattern,'$1', $js4);
    $js6 = str_replace(":+",":",$js5);  //remove the added '+'

    $js7 = '{"$schema":"'.$schema.'",'.substr($js6,1);   //prepend the schema

    return $js7;
}


/******************************************************************************/


function load_dict() {

    //Load CSV dictionary
 //This comprises (short_form),(long_form),(control)
 //Control may be 0,1 or 2. 0=only parameter names,1= only parameter values,2=either
 $row = 0;
 $dict_file = __DIR__."/dict.csv";
 $dict_table = [];
 $dict_handle = fopen($dict_file, "r") or die("Dictionary $dict_file not found!");
 while (($data = fgetcsv($dict_handle, 1000, ",")) !== FALSE) {
     $num = count($data);
     if ($num == 2) {
         array_push($dict_table,$data);
     } else {
         die("Unrecognised dictionary format in $dict_file!");
     }
 }
 fclose($dict_handle);
 //report("Dict loaded (".count($dict_table)." records)",3);
 return($dict_table);

}

function shortlong($short_text) {
 // Use a dictionary stored in dict.csv to expand parameter names and values into something more readable

 $dict_table = load_dict();
 $result = $short_text;
 foreach ($dict_table as $dict_entry) {
     $result = str_replace('"'.$dict_entry[0].'"','"'.$dict_entry[1].'"',$result);
 }
 return($result);
}


function longshort($long_text) {
 // Use a dictionary stored in dict.csv to compress parameter names/values into 2 chars

 $dict_table = load_dict();

 //remove the schema
 $result = preg_replace('/(\s)*"\$schema"[^,]+,[\n\r]*/',"",$long_text);
 
 foreach ($dict_table as $dict_entry) {
     $result = str_replace('"'.$dict_entry[1].'"','"'.$dict_entry[0].'"',$result);
 }

 return($result);

}


?>
