<?php

//start with a system dataset with full paths added
// split out the netlist from the array of products
// for all products, 
//      create an array of product_name!port_name and port data

//for each netlist node
//  confirm that we have enough connectors of the correct type
//  if necessary
//     clear the compatible_flag and generate a report
//     if stop_on_fail set, stop

function conn_compat($system) {
    //return true or false for the electrical compatibility of a system
    global $stop_on_fail,$c_check;

    return ("noInfo");

    //build a complete list of all the system products' ports
    //each array element is keyed by product!port
    //and contains the elements on that port
    if (!is_array($system[0])) {
        return ("dataError");
    }
    $productlist = $system[0];  //all the products in the system
    $conn_list = array();
    foreach ($productlist as $product) {
        $ports = $product[1];   //all the ports on this product
        if (is_string($ports[0])) {        //in case there's only one port
            $ports = [$ports];
        }
        foreach ($ports as $port) {
            $portname = $port[0];   //this will be product!port
            report ("Adding connector (count=".strval(count($port[2])). ") at port $portname to connector list",2);
            $conn_list[$portname] = $port[2];    //connector data
 
        }
    }

    $netlist = $system[1];  //array of nodes
    if (find_type($netlist) == "net_entry") {  //if there is only one node
        $netlist = [$netlist];
    }

    foreach ($netlist as $index => $node) {   // check all the nodes in the  netlist

        report ("Checking node $index",2);
        $node_connectors = array();
        $port_list = "(";
        foreach ($node as $portID) {    //assemble all the connected ports' connector data from the keyed array

            $port_list .= $portID.", ";  //just for reporting

            if (!array_key_exists($portID,$conn_list)) {
                report ("Netlist port $portID not found in system");
                return null;
            }
            array_push($node_connectors,$conn_list[$portID]); 

        }
        $port_list = trim($port_list,", ").")";  //just for reporting

        //report on what we've got
        $gender = array('_P' => 'plug','_S' => 'socket', '_H' => 'hermaphroditic');
        $fixed_free = array('_x' => 'fixed','_X' => 'fixed','_e' => 'free','_E' => 'free');
        report ("Node connectors for ".count($node_connectors)."products are:<ul>",3);
        foreach ($node_connectors as $node_connector) { //report if requested
            $conn_data = $node_connector[0]."(".$gender[$node_connector[1]].",".$fixed_free[$node_connector[2]].")";
            if (!is_null($node_connector[3])) {
                $conn_data .= " #=".strval($node_connector[3]);
            }
            if (!is_null($node_connector[4])) {
                $conn_data .= " GSD=".strval($node_connector[4]);
            }
            report("<li>".$conn_data."</li>",3); 
        }
        report ("</ul>",3); //end reporting

        $compatible_flag = true;
        //Are all connectors of the same type?
        $conn_type = null;
        foreach ($node_connectors as $node_connector) {
            $c_check++;
            if (is_null($conn_type)) {
                $conn_type = $node_connector[0];
            } else {
                if ($conn_type != $node_connector[0]) {
                    $compatible_flag = "no";
                    report("Connectors are of different types: ".$conn_type." != ".$node_connector[0],1);
                    if ($stop_on_fail) {
                        return "no";    //              if stop_on_fail set, stop
                    }
                }
            }
        }
        //Are there enough plugs and sockets available on this node for n connections?
        //For plug+skt, there must be a total of >=(n-1) of each,
        $n_count = count($node_connectors) - 1;
        $p_count = 0;
        $s_count = 0;
        $h_count = 0;
        $free_count = 0;
        foreach ($node_connectors as $node_connector) {
            $c_check++;
            if (is_numeric($node_connector[3])) {
                $ways = $node_connector[3];
            } else {
                $ways = 1;
            }
            if (strtolower($node_connector[2]) == "_e") {
                $free_count += $ways;
            }
            if ($node_connector[1] == "_P") {
                $p_count += $ways;
            }
            if ($node_connector[1] == "_S") {
                $s_count += $ways;
            }
            if ($node_connector[1] == "_H") {
                $h_count += $ways;
            }
        }
        report ("P=$p_count, S=$s_count, H=$h_count, F=$free_count",3);
        if ($h_count > 0) {
            $x_count = min($h_count,$free_count);
        } else {
            $x_count = min($p_count,$s_count,$free_count);
        }
        if ($x_count < $n_count) {  //not enough connectors
            $compatible_flag = "no";
            report ("There are insufficient connectors of the correct gender at node $index ($n_count needed, $x_count available)",1);
            if ($stop_on_fail) {
                return "no";    //              if stop_on_fail set, stop
            }
        }
        if ($compatible_flag) {
            report("At node ".$index.", all connections ".$port_list." are mechanically compatible");
        }

    }       //next netlist node

    return $compatible_flag;
}


?>
