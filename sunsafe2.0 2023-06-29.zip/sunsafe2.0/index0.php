
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2022-03-08    chris.moller@evonet.com -->
	<title>Sunsafe Compatibility Checker</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2/index0.php       -->
	<meta charset="utf-8">

    <link href="dual-listbox.css" rel="stylesheet">

	<style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: white;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }

	</style>

    <script src="dual-listbox.js"></script>
    
    <script>

        demo =new DualListbox('.selectDemo');

        dualListbox.addEventListener("added", function(event) {
            console.log(event);
            console.log(event.addedElement);
        });
        dualListbox.addEventListener("removed", function(event) {
            console.log(event);
            console.log(event.removedElement);
        });
    </script>
	
</head>

<body >

<h1>Sunsafe Compatibility Checker</h1>

<p>On this page, select the data files for the products that will form the system.</p>

<form action="index1.php" method="GET" name="inputData" id="inputData">

<?php

    echo ('<select class="select1" name="files[]" id="files[]" multiple>');
    $files = scandir ('data');
    foreach ($files as $file) {
        if ((str_ends_with(strtolower($file),'.json')) or (str_ends_with(strtolower($file),'.qrc'))) {
            echo('    <option value="'.$file.'">'.$file.'</option>'.PHP_EOL);
        }
    }
    echo ('</select>');

?>

<script src="dual-listbox.js"></script>
<script>
    dlb1 = new DualListbox('.select1', {
        availableTitle: "Available products",
        selectedTitle: "Selected products",
        sortable: false,
        addButtonText: ">",
        removeButtonText: "<",
        addAllButtonText: ">>",
        removeAllButtonText: "<<"
    });
</script>



    <input name="submit2" type="submit" value="Next...">


</form>




</body>
</html>

