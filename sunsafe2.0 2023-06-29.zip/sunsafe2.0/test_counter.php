<?php

require "globals.php";

echo("<br/>Test Counter routines<br/>");


function test_n_ary_counter() {
    global $counter, $n_ary;

    $number = 0;
    echo(get_counter()." should be null<br/>");     //not initialised
    initialise_counter(3);
    echo(get_counter()." should be null<br/>");     //not an array
    initialise_counter([1,"fred",2,3]);
    echo(get_counter()." should be null<br/>");     //rubbish input

    initialise_counter([2,1,4]);
    echo("<br/>Initialised<br/>");
    print_r($n_ary);
    echo("<br/>Initialised<br/>");
    do {
        $result = get_counter();
        echo ("<pre>");
        print_r($result);
        echo ("</pre><br/>"); 
        $number++;
        
    } while ((!is_null($result)) and ($number < 100));

    initialise_counter([1,1,1]);
    echo("<br/>Initialised<br/>");
    print_r($n_ary);
    echo("<br/>Initialised<br/>");
    do {
        $result = get_counter();
        echo ("<pre>");
        print_r($result);
        echo ("</pre><br/>"); 
        $number++;
        
    } while ((!is_null($result)) and ($number < 100));


}


test_n_ary_counter();
     

output_report();

?>
