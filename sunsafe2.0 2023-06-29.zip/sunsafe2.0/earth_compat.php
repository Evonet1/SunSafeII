<?php


function add_earthing($earth1,$earth2) {
    // Each input parameter is a string with a value of one of 
    // "T+","T-","TV","IT","D+","D-","DV","T-E","T-E","TVE","ITE","D+E","D-E","DVE"
    // The output is in the same format, or "X" if incompatible
    global $d_check;

    if (($earth1 == "X") or ($earth2 == "X")) {
        return "X"; //incompatible already
    }

    $earthTable = [
        ["T+T+","X"],
        ["T+T-","X"], ["T-T-","X"],
        ["TVT+","X"], ["TVT-","X"], ["TVTV","X"],
        ["ITT+","T+"], ["ITT-","T-"], ["ITTV","TV"], ["ITIT","IT"],
        ["D+T+","T+"], ["D+T-","X"],  ["D+TV","X"],  ["D+D+","D+"], ["D+IT","D+"],
        ["D-T+","X"], ["D-T-","T-"], ["D-TV","X"], ["D-IT","D-"],  ["D-D+","X"], ["D-D-","D-"],
        ["DVT+","X"],  ["DVT-","X"],  ["DVTV","X"],  ["DVIT","DV"],  ["DVD+","X"],  ["DVD-","X"],["DVDV","X"],
        ["T+ET+","X"], ["T+ET-","X"], ["T+ETV","X"], ["T+EIT","T+E"], ["T+ED+","T+E"], ["T+ED-","X"], ["T+EDV","X"],
        ["T+ET+E","X"],
        ["T-ET+","X"], ["T-ET-","X"], ["T-ETV","X"], ["T-EIT","T-E"], ["T-ED+","X"], ["T-ED-","T-E"], ["T-EDV","X"],
        ["T-ET+E","X"], ["T-ET-E","X"],
        ["TVET+","X"], ["TVET-","X"], ["TVETV","X"], ["TVEIT","TVE"], ["TVED+","X"], ["TVED-","X"], ["TVEDV","TVE"],
        ["TVET+E","X"], ["TVET-E","X"], ["TVETVE","X"],
        ["ITET+","T+E"],["ITET-","T-E"],["ITETV","TVE"],["ITEIT","ITE"],["ITED+","D+E"],["ITED-","D-E"],["ITEDV","DVE"],
        ["ITET+E","T+E"],["ITET-E","T-E"],["ITETVE","TVE"],["ITEITE","ITE"],
        ["D+ET+","T+E"],["D+ET-","X"],["D+ETV","X"],["D+EIT","D+E"],["D+ED+","D+E"],["D+ED-","X"],["D+EDV","X"],
        ["D+ET+E","T+E"],["D+ET-E","X"],["D+ETVE","X"],["D+EITE","D+E"],["D+ED+E","D+E"],["D+ED-E","X"],["D+EDVE","X"],
        ["D-ET+","X"],["D-ET-","T-E"],["D-ETV","X"],["D-EIT","D-E"],["D-ED+","X"],["D-ED-","D-E"],["D-EDV","X"],
        ["D-ET+E","X"],["D-ET-E","T-E"],["D-ETVE","X"],["D-EITE","D-E"],["D-ED+E","X"],["D-ED-E","D-E"],
        ["DVET+","X"],["DVET-","X"],["DVETV","X"],["DVEIT","DVE"],["DVED+","X"],["DVED-","X"],["DVEDV","X"],
        ["DVET+E","X"],["DVET-E","X"],["DVETVE","X"],["DVEITE","DVE"],["DVED+E","X"],["DVED-E","X"],["DVEDVE","X"]
        
    ];
    $sum = $earth1.$earth2;
    report ("Adding earthing $sum",4);
    $result = "";
    $d_check++;
    foreach ($earthTable as $tableEntry) {
        if ($tableEntry[0] == $sum) {
            $result = $tableEntry[1];
            return $result;
        }
    }
    $sum = $earth2.$earth1;
    foreach ($earthTable as $tableEntry) {
        if ($tableEntry[0] == $sum) {
            $result = $tableEntry[1];
            return $result;
        }
    }
    report("Bad data entry to add_earthing($sum)",1);
    return "X";

}

function add_classes($class1,$class2) {
    // Each input parameter is a string with a value of one of 
    // "Class 0", "Class I","Class 0I","Class II","Class IIFE","Class III+","Class III-"
    // The output is in the same format, or "X" if incompatible
    global $d_check;

    if ($class1 == $class2) {
        $d_check++;
        return $class1;
    }
    if (($class1 == "X") or ($class2 == "X")) {
        return "X"; //incompatible already
    }

    $classTable = [
        ["Class I,Class 0","Class I"],
        ["Class 0I,Class 0","Class 0"],
        ["Class II,Class 0","Class 0"], ["Class II,Class I","Class I"],
        ["Class IIFE,Class 0","Class I"],["Class IIFE,Class I","Class I"],["Class IIFE,Class 0I","Class 0I"],
        ["Class III+,Class 0","Class III+"],["Class III+,Class I","Class III+"],["Class III+,Class 0I","Class III+"],
        ["Class III+,Class II","Class III+"],["Class III+,Class IIFE","Class III+"],
        ["Class III-,Class 0","Class III-"],["Class III-,Class I","Class III-"],["Class III-,Class 0I","Class III-"],
        ["Class III-,Class II","Class III-"],["Class III-,Class IIFE","Class III-"],["Class III-,Class III+","X"]
    ];

    $classes = $class1.",".$class2;
    report ("Adding classes $classes",4);
    $result = "";
    foreach ($classTable as $tableEntry) {
        if ($tableEntry[0] == $classes) {
            $result = $tableEntry[1];
            $d_check++;
            return $result;
        }
    }
    $classes = $class2.",".$class1;
    foreach ($classTable as $tableEntry) {
        if ($tableEntry[0] == $classes) {
            $result = $tableEntry[1];
            $d_check++;
            return $result;
        }
    }
    report("Bad data entry to add_classes($classes)",1);
    return "X";
    report ("Adding classes $classes",4);

}

function earth_compat($nodelist,$php_data) {
    //return true or false for the earthing compatibility of a node
    global $stop_on_fail,$d_check;

    $earthing = "";
    $insulClass = "";

    report("Checking earthing for ".count($nodelist)." items",4);
    foreach ($nodelist as $prodPort) {
        $earthInfo = false;
        $reference = explode("!",$prodPort);    //separate out product and port
        if (count($reference) < 2) {
            echo("Faulty port reference <i>$port</i> in netlist");
            exit(1);
        }
        $productName = $reference[0];
        $portName = $reference[1];
        if (!array_key_exists($productName,$php_data)) {
            echo("Nodelist contains unknown product $productName");
            exit(1);
        }
        $productData = $php_data[$productName];

        //first pull out all the insulation class data for each product referenced in the netlist
        if (array_key_exists("insulationClass",$productData)){
            $earthInfo = true;
            $prodInsClass = $productData["insulationClass"];
            if ($insulClass == "") {    //first
                $insulClass = $prodInsClass;
            } else {
                $insulClass = add_classes($insulClass,$prodInsClass);
            }
        } 

        //now pull out the earthing data for the relevant port
        $portData = $productData["port"];       //if there isn't a port key, we'll have trapped it before
        //This is now the port data for all the ports on a particular product
        if (array_key_exists("portName",$portData)) { //if there is only one port and it isn't an array,
            $portData = [$portData];    //make it into an array
        }
        foreach ($portData as $possPort) {      //check all the ports for this product
            //Find the port referenced in the netlist
            if ($possPort["portName"] == $portName) {   //this is the port we need earthing data for
                if (array_key_exists("earthing",$possPort)){  //we have earthing info
                    $earthInfo = true;
                    if ($earthing == "") {  //this is the first
                        $earthing = $possPort["earthing"];
                    } else {
                        $earthing = add_earthing($earthing,$possPort["earthing"]);
                    }
                }
            }
        }
        if (!$earthInfo) {
            report("No earthing or insulation data for $productName",3);
            return "noInfo";    //we have to fail the whole check if one port has neither insulation class nor earthing info
        }
    }

    //The combined earthing system is now $earthing, and the combined classes $insulClass
    report("Earthing system is $earthing",4);
    report("Insulation classes are $insulClass",4);

    if ($earthing == "") {
        return "noInfo";
    }

    $d_check++;
    switch($insulClass) {
        case "Class 0":
        case "Class 0I":
        case "Class II":
            return "OK";
            break;
        case "Class I":
        case "Class IIFE":
            if (str_contains($earthing,"E")) {
                return "OK";
            }
            break;
        case "Class III+":
            if (str_contains($earthing,"+")) {
                return "OK";
            }
            break;
        case "Class III-":
            if (str_contains($earthing,"-")) {
                return "OK";
            }
            break;
        default:
            report("Insulation classes contains illegal value $insulClass",2);
            return "NO";
    }
    return "NO";

}    

?>
