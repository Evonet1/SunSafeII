
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2023-08-15    chris.moller@evonet.com -->
	<title>Sunsafe Appliance Data Capture 2</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2.9/appdatacollect.php       -->
	<meta charset="utf-8">

	<style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: lightblue;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }
 

	</style>

	
</head>

<body >

    <h1>Appliance data capture</h1>
    <p align="center">To pre-populate this page with default values for a particular type of appliance,<br/> select the appliance, and click 'Load defaults'</p>

<?php

    //We will deliver to app2json.php:
    //mfr,model,description,voltage,frequency,current,Runits,averagePower,Aunits,protocol, filename


    require_once("json_utilities.php");
    require_once("common_routines.php");



    $dict = load_dict();

    //populate appliances list
    echo ('<datalist id="appliances">' . PHP_EOL);
    genOptions("@");
    echo ('</datalist>' . PHP_EOL);

    //populate appliances list
    echo ('<datalist id="infrastructure">' . PHP_EOL);
    genOptions("?");
    echo ('</datalist>' . PHP_EOL);

    //populate protocols list
    echo ('<datalist id="protocols">' . PHP_EOL);
    genOptions("^");
    echo ('</datalist>' . PHP_EOL);


?>

    <form  action="app2json.php" method="GET" name="inputData" id="inputData">

        <table align="center">
            <tr>
                <td colspan="3" align="center">
                    <b>General</b>
                </td>
            </tr>
            <tr>
                <td align="right">Product and model</td>
                <td colspan="2">
                    <input size="32" id="product" name="product" value="" />
                </td><td>&nbsp;</td>
            </tr>

            <tr>
                <td align="right">Description</td>
                <td>
                    <input id="description" name="description" list="appliances" />
                </td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td colspan="3" align="center">
                    <b>Electrical characteristics</b>
                </td>
            </tr>
            <tr>
                <td align="right">Supply voltage:</td>
                <td><input id="voltage" name="voltage" value="" />
                </td><td>Volts*</td>
            </tr>
            <tr>
                <td align="right">Supply frequency:</td>
                <td><select  name="iFrequency" id="iFrequency">
                    <?php
                    genOptions("&");   
                    ?> 
                </select></td>                </td><td>&nbsp;</td>
            </tr>
            <tr>
                <td align="right">Rated power/current</td><td>
                    <input id="ampsWatts" name="ampsWatts" value="" />
                </td><td><select  name="Runits" id="Runits">
                    <option value="Watts" selected>Watts</option>
                    <option value="Amps">Amps</option>
                    </select></td>
             </tr>
            <tr>
                <td align="right">Average operating power</td><td>
                    <input id="averagePower" name="averagePower" value="" />
                </td><td>Watts</td>
            </tr>    
            <tr>
                <td align="right">Power signalling protocol</td><td>
                    <input id="protocol" name="protocol" list="protocols" />
                </td><td>&nbsp;</td>
            </tr>
            <tr>
                <td align="right">Typical daytime usage</td><td>
                    <input type="text" id="dayTime" name="dayTime" value="0" />
                </td><td><select  name="dayUnits" id="dayUnits">
                    <option value="hrs" selected>hrs</option>
                    <option value="mins">mins</option>
                    </select></td>
            </tr>
            <tr>
                <td align="right">Typical night-time usage</td><td>
                    <input type="text" id="nightTime" name="nightTime" value="0" />
                </td><td><select  name="nightUnits" id="nightUnits">
                    <option value="hrs" selected>hrs</option>
                    <option value="mins">mins</option>
                    </select></td>
            </tr>

            <tr>
                <td colspan="3" align="center">
                    <b>Save</b>
                </td>
            </tr>       <tr>
                <td align="right">Product data file name</td><td>
                    <input id="fileName" name="fileName" value="" />
                </td><td>.json</td>
            </tr>   
        </table>


        <p  align="center"><input name="submit" type="submit" value="Create JSON file..." /></p>


    </form>

    <p align="center">* For voltage, a range (eg 9-15) may be given.  Alternative settings (eg 110,230)<br/>
    or even (110-120,220-240) may be entered, though thought must be given to how <br/>
    the correct alternative will be selected, either manually or in software. <br/>
    (Compatibility will be assumed if ANY ONE of the alternatives offered is suitable.)</p>


</body>
</html>

