<?php
error_reporting(-1);
ini_set("display_errors", 1);
session_start();

$debug = false;

$script = substr(strrchr(__FILE__, "/"), 1); //get the name of this file, so we can return to it after adding/deleting


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2023-07-29    chris.moller@evonet.com -->

    <meta charset="utf-8" />
    <title>Sunsafe II</title>


    <style type="text/css">


		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 1px solid black;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: white;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 1px solid black;
        }
        td {
            text-align: center;
        }
        .button1 {
            box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 35px 0 rgba(0,0,0,0.19);
        }

	</style>

</head>
<body>

    <?php


 //   require "../json_utilities.php";
    require "rulecheck.php";

    if ((!isset($_SESSION['componentList'])) or (key_exists("reset",$_GET))) {    //This is where the current list of components is stored
        $_SESSION['componentList'] = array();
        echo ("Resetting session!");
    }
    $_SESSION['netlist'] = array();     //start with an empty netlist

    $script = substr(strrchr(__FILE__, "/"),1); //get the name of this file, so we can return to it after adding/deleting

    if (key_exists("remove",$_GET)) {
        $del_index = $_GET["remove"];
        array_splice($_SESSION['componentList'], $del_index, 1, []);
    }


    if (key_exists("addFile", $_GET)) {
        $file = $_GET["addFile"];
        if (str_ends_with(strtolower($file), '.json')) {
            $appdata = file_get_contents("data/" . $file, true);
            $app_data = json_decode($appdata, true);
            if (!is_null($app_data)) {
                $_SESSION["componentList"][] = $app_data;
            }
        }
    }

    if (key_exists("edit", $_GET)) {
        $index = $_GET["edit"];
        $component = $_SESSION["componentList"][$index];
        $energy = $component["energy"];
        $energy["dayHrs"] = $_GET["dayHours"];
        if (key_exists("nightHours",$_GET)) {
            $energy["nightHrs"] = $_GET["nightHours"];
        }
        $component["energy"] = $energy;
        $_SESSION["componentList"][$index] = $component;
        echo ("updated");
    }


    $solarPanel = "";
    $solarHrs = 5;
    $solarSer = 1;
    $solarPar = 1;
    $batts = "";
    $battSer = 1;
    $battPar = 1;
    $battMin = 20;

    ?>
    <h2>Solar Home System Builder</h2>

    <p>Add components to the system as required.</p>
    <form action="appdatacollect.php" method="GET" name="inputData" id="inputData">
   <!-- Solar panels -->
    <table border="0" cellspacing="0">
        <tr>
            <td align="center" colspan="2">
                <b>Solar panels</b>
            </td>
        </tr>
        <tr>
            <td align="right">Product:</td>
            <td><input type="text" size = "22" name="solarP" id="solarP" value="<?=$solarPanel?>"/></td>
        </tr>
        <tr>
            <td align="right">Effective hours/day:</td>
            <td>
                <input type="number" style="width: 35px" name="solarHrs" id="solarHrs" value="<?=$solarHrs?>" />
            </td>
        </tr>
        <tr>
            <td align="right">Quantity in series:</td>
            <td>
                <input type="number" style="width: 35px" name="solarSer" id="solarSer" value="<?=$solarSer?>" />
            </td>
        </tr>
        <tr>
            <td align="right">Quantity in parallel:</td>
            <td>
                <input type="number" style="width: 35px" name="solarPar" id="solarPar" value="<?=$solarPar?>" />
            </td>
        </tr>
    </table>
    <p></p>
    <table border="1" cellspacing="0">
        <tr>
            <td align="center" colspan="2">
                <b>Infrastructure components</b>
            </td>
            <td ><b><a href="<?=$script?>?reset=1">X</a></b></td>
        </tr>
        <tr>
            <td width="25">&nbsp;</td><td width="275">&nbsp;</td><td>X</td>
        </tr>
        <tr>
            <td>&nbsp;</td><td>&nbsp;</td><td>X</td>
        </tr>
        <tr>
            <td>&nbsp;</td><td>&nbsp;</td><td>X</td>
        </tr>
    </table>
    <p></p>
    <table border="0" cellspacing="0">
        <tr>
            <td align="center" colspan="2">
                <b>Batteries</b>
            </td>
        </tr>
        <tr>
            <td align="right">Product:</td>
            <td>
                <input type="text" size="22" name="batts" id="batts" value="<?=$batts?>" />
            </td>
        </tr>
        <tr>
            <td align="right">Minimum charge%:</td>
            <td>
                <input type="number" style="width: 35px" name="battMin" id="battMin" value="<?=$battMin?>" />%
            </td>
        </tr>
        <tr>
            <td align="right">Quantity in series:</td>
            <td>
                <input type="number" style="width: 35px" name="battSer" id="battSer" value="<?=$battSer?>" />
            </td>
        </tr>
        <tr>
            <td align="right">Quantity in parallel:</td>
            <td>
                <input type="number" style="width: 35px" name="battPar" id="battPar" value="<?=$battPar?>" />
            </td>
        </tr>
    </table>
    <p></p>
    <table border="1" cellspacing="0">
        <tr>
            <td align="center" colspan="5" width="320"><b>Appliances</b></td>
        </tr>
        <tr>
            <td rowspan="2" width="25">&nbsp;</td><td align="center" rowspan="2" width="220">Product:</td>
            <td align="center" colspan="2">hrs/day</td>
            <td rowspan="2"><b><a href="<?=$script?>?reset=1">X</a></b></td>
        </tr>
        <tr>
            <td><img src="img/day.jpg" width="25"/></td><td><img src="img/night.jpg" width="25"/></td>
        </tr>

        <?php
        $defaultData = file_get_contents("appliances.json", true);  //pre-load default appliance data
        $default_data = json_decode($defaultData, true);
        $defaultAppliances = $default_data["appliances"];

        $index = 0;
        foreach($_SESSION['componentList'] as $component) {
            $dayHrs = "&nbsp;";
            $nightHrs = "&nbsp;";
            if (is_array($component)) {
                if (key_exists("apType", $component)) { //we have an appliance
                    $apType = $component["apType"];
                    $prompt = $apType. "<br/>(" . $component["brand"] . " " . $component["model"] . ")";
                    if (key_exists("energy",$component)) {
                        $energy = $component["energy"];
                        if (key_exists("dayHrs",$energy)) {
                            $dayHrs = $energy["dayHrs"];
                        }
                        if (key_exists("nightHrs",$energy)) {
                            $nightHrs = $energy["nightHrs"];
                        }
                    }
                    if (($dayHrs == "&nbsp;") or ($nightHrs == "&nbsp;")){  //hrs of use have not been set, so use defaults
                        foreach ($defaultAppliances as $defaultAppliance) {
                            if ($defaultAppliance["apType"] == $apType) {
                                if (key_exists("defaultDayHours", $defaultAppliance)) {
                                    $dayHrs = $defaultAppliance["defaultDayHours"];
                                }
                                if (key_exists("defaultNightHours", $defaultAppliance)) {
                                    $nightHrs = $defaultAppliance["defaultNightHours"];
                                }
                                break;
                            }
                        }
                    }
                    if ($apType == "solarPanel") {
                        $tableRow = '<tr><td>' . $index . '</td><td><a href="editsolar.php?component=' . $index . '">' . $prompt . '</a>';
                    } else {
                        $tableRow = '<tr><td>'.$index.'</td><td><a href="edit.php?component=' . $index . '">' . $prompt . '</a>';
                    }
                } else {
                    $prompt = $component["brand"] . " " . $component["model"];
                    $tableRow = '<tr><td>' . $index . '</td><td>'.$prompt;
                    $dayHrs = "&nbsp;";
                    $nightHrs = "&nbsp;";
                }
                $tableRow .= '</td><td align="center">'.$dayHrs.'</td><td align="center">' . $nightHrs . '</td>';
                $tableRow.= '<td align="center"><a href="'.$script.'?remove=' . $index . '">X</a></td></tr>';
                echo ($tableRow);
                $component["dayHrs"] = $dayHrs;
                $component["nightHrs"] = $nightHrs;
                $_SESSION["componentList"][$index] = $component;
            }
            $index++;
        }
        ?>

        <tr>
            <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>X</td>
        </tr>
        <tr>
            <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>X</td>
        </tr>

    </table>
    <p>Add a component:</p>
    <p><button class="button1" name="readQR" id="readQR" onclick="location.href='readQR.php'" disabled>From QR code</button>
    &nbsp;&nbsp;
    <button class="button1" name="readQR" id="readQR" onclick="location.href='readfile.php'">From JSON file</button></p>
    <p></p>
    <p><button class="button1" name="check" id="check" onclick="location.href='check.php'">Check compatibility</button>
</p>
 


</body>
</html>