
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2023-08-15    chris.moller@evonet.com -->
	<title>Save Infrastructure JSON file</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2.7/batt2json.php       -->
	<meta charset="utf-8">

	<style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: lightblue;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }
 

	</style>

	
</head>

<body >

    <?php


    error_reporting(-1);
    ini_set("display_errors", 1);

    /* This generates a JSON file for a standalone battery
     *     inputs are: mfr, model, voltage, protocol, eff, filename

    */

    define("VERSION" , "2.10");

    require_once("json_utilities.php");
    require_once("common_routines.php");


    $fileName = $_GET["fileName"].".json";

    $product = $_GET["product"];
    $description = $_GET["description"];
    $voltage = $_GET["voltage"];
    $protocol = $_GET["protocol"];
    $capacity = $_GET["capacity"];
    $capUnits = $_GET["capUnits"];
    $eff = $_GET["eff"];


    echo ("<h1>Sunsafe JSON file creation for $description $product</h1>");

    $energy = array();

    $data = array();
    $data['$schema'] = "../sunsafe".VERSION.".json";
    $data["product"] = $product;
    $data["description"] = $description;

    $energy["perHour"] = 0;
    if ($capUnits == "Amp-hours") {
        $capacity = dp2($capacity * $voltage);
    }
    $energy["capacity"] = $capacity;
    $energy["perHour"] = 0;
    $energy["efficiency"] = dp2(floatval($eff)/100);

    $data["ports"] = array();

    $port = array();
    $port["name"] = "battery";
    $port["function"] = ["requires" => "battPort"];
    $port["connections"] = ["requires" => 1];
    $bVoltage = inputVoltage($voltage, 0);

    $port["voltage"] = ["requires" =>$bVoltage];
    $port["protocol"] = ["requires" => $protocol];
    array_push($data["ports"], $port);

    $data["energy"] = $energy;


    $fileName = $_GET["fileName"].".json";

    $fileText = json_encode($data, JSON_PRETTY_PRINT);

//    echo ($fileText);

    $myfile = fopen("data/".$fileName,"w");
    fwrite($myfile,$fileText);
    fclose($myfile);



    echo ("<p>File $fileName successfully created</p>");



    ?>

    <form action="phpqrcode/p2.php" method="GET" name="inputData" id="inputData">
        <input type="hidden" id="file" name="file" value="<?=$fileName?>" />

        <input name="submit" type="submit" value="View the created JSON data..." />

    </form>

</body>
</html>

