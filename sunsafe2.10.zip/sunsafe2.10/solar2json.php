
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2023-07-25    chris.moller@evonet.com -->
	<title>Save Infrastructure JSON file</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2.7/solar2json.php       -->
	<meta charset="utf-8">

	<style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: lightblue;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }
 

	</style>

	
</head>

<body >

    <?php


    error_reporting(-1);
    ini_set("display_errors", 1);

    /* This generates a JSON file for a standalone solar panel
     * The inputs are:  mfr, model, ocv, scc, wpk, filename

    */

    define("VERSION" , "2.10");

    require("json_utilities.php");


    $fileName = $_GET["fileName"].".json";

    $product = $_GET["product"];
    $ocv = floatval($_GET["ocv"]);
    $scc = floatval($_GET["scc"]);
    $wpk = floatval($_GET["wpk"]);


    echo ("<h1>Sunsafe JSON file creation for $product</h1>");

    $energy = array();



    $data = array();
    $data['$schema'] = "sunsafe".VERSION.".json";
    $data["product"] = $product;
    $data["description"] = "Solar panel";

    $energy["perHour"] = $wpk;


    $data["ports"] = array();

    $port = array();
    $port["name"] = "Out";
    $port["function"] = ["requires" => "solarIn"];
    $port["connections"] = ["requires" => 1];
    $port["voltage"] = ["requires" => [[$ocv,$ocv]]];
    $port["ampsWatts"] = ["requires" => ["value" => -$scc,"units" => "Amps"]];
    $port["protocol"] = ["requires" => "solarIn"];
    array_push($data["ports"], $port);



    $data["energy"] = $energy;




    $fileName = $_GET["fileName"].".json";

    $fileText = json_encode($data, JSON_PRETTY_PRINT);

    $myfile = fopen("data/".$fileName,"w");
    fwrite($myfile,$fileText);
    fclose($myfile);


    echo ("<p>File $fileName successfully created</p>");


    ?>

    <form action="phpqrcode/p2.php" method="GET" name="inputData" id="inputData">
        <input type="hidden" id="file" name="file" value="<?=$fileName?>" />

        <input name="submit" type="submit" value="View the created JSON data..." />

    </form>

</body>
</html>

