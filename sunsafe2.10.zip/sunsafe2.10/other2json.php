
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2023-07-25    chris.moller@evonet.com -->
	<title>Save Infrastructure JSON file</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2.7/other2json.php       -->
	<meta charset="utf-8">

	<style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: lightblue;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }
 

	</style>

	
</head>

<body >

    <?php


    error_reporting(-1);
    ini_set("display_errors", 1);

    /* This generates a JSON file for a complex component
       inputs are:
            product
            description
            wpk
            ocv
            scc
            maxConns
              iName[]
              iVoltage[]
              iFrequency[]
              iAW[]
              iUnits[]
              iProtocolO[]
              iProtocolR[]
            battV
            battConns
            ctlChem[]
            capacity
            capacityA
            capacityV
            battEff
              oName[]
              oType
              oVoltage[]
              oFrequency[]
              oAW[]
              oUnits[]
              oProtocolO[]
              oProtocolR[]
              loadConns[]
            loss
            efficiency
            fileName


              */

    define("VERSION" , "2.10");

    require_once ("common_routines.php");
    require_once("json_utilities.php");


    $fileName = $_GET["fileName"].".json";

    $product = $_GET["product"];
    $description = $_GET["description"];
    $functions = array();



    echo ("<h1>Sunsafe JSON file creation for $product ($description)</h1>");



    $data = array();
    $energy = array();

    $data['$schema'] = "../sunsafe".VERSION.".json";
    $data["product"] = $product;
    $data["description"] = $description;
    $ports = array();

    //Deal with solar input
    if (key_exists("ocv", $_GET)) {
        $functions[] = "Solar controller";
        $ocv = inputVoltage(checkKey("ocv"),0);
        $scc = checkKey("scc");
        $maxConns = checkKey("maxConns");
        $maxConns = intval($maxConns);
        if ($maxConns == -1) {
            $maxConns = "U";
        }
        $port = array();
        $port["name"] = "SolarIn";
        $port["function"] = ["offers" => "solarIn"];
        $port["connections"] = ["offers" => $maxConns];
        $port["voltage"] = ["offers" => $ocv];
        $port["ampsWatts"] = ["offers" => ["value" =>-floatval($scc), "units" =>"Amps"]];
        $port["protocol"] = ["offers" => "solarIn"];
        array_push($ports, $port);
    }

    //deal with any number of general inputs
    if (key_exists("iName",$_GET)) {
        $iNames = $_GET["iName"];
        $functions[] = "General input";
        for ($iIndex = 0; $iIndex < sizeof($iNames); $iIndex++) {
            $iName = $iNames[$iIndex];
            $iVoltage = inputVoltage($_GET["iVoltage"][$iIndex],5);
            $iFrequency = $_GET["iFrequency"][$iIndex];
            $iAW = $_GET["iAW"][$iIndex];
            $iUnits = $_GET["iUnits"][$iIndex];
            $iProtocolO = $_GET["iProtocolO"][$iIndex];
            $iProtocolR = $_GET["iProtocolR"][$iIndex];

            $iVoltage = ["requires" => $iVoltage ];

            if ($iFrequency == "") {
                $iFrequency = "DC(0Hz)";
            }
            $iFrequency = ["requires" => $iFrequency];

            $port = array();
            $port["name"] = $iName;
            $port["function"] = ["requires" => "output"];
            $port["connections"] = ["requires" => 1];
            $port["voltage"] = $iVoltage;
            $port["ampsWatts"] = ["requires" =>["value" => floatval($iAW), "units" => $iUnits]];
            $port["frequency"] = $iFrequency;
            $port["protocol"] = ["offers" => $iProtocolO, "requires" => $iProtocolR];
            array_push($ports, $port);
        }

    }

    //Deal with an exposed battery port
    if (key_exists("battV", $_GET)) {
        $functions[] = "Charge controller";
        $battV = inputVoltage(checkKey("battV"),0);
        $battA = checkKey("battA");
        $battConns = checkKey("battConns");
        $battConns = intval($battConns);
        if ($battConns == -1) {
            $battConns = "U";
        }
        $port = array();
        $port["name"] = "battPort";
        $port["function"] = ["offers" => "battPort"];
        $port["connections"] = ["offers" => $battConns];
        $port["voltage"] = ["offers" => $battV];
        $pcol = $_GET["ctlChem"];
        $pcol1 = ["offers" => $pcol ];
        $port["protocol"] = $pcol1;
        array_push($ports, $port);
    }

    //Deal with battery energy
    if (key_exists("capacity", $_GET)) {
        $functions[] = "Battery";
        $capacity = floatval($_GET["capacity"]);
        $capacityA = checkKey("capacityA");
        $capacityV = checkKey("capacityV");
        if (($capacityA != "") and ($capacityV != "")) {
            $capacity = floatval($capacityA) * floatval($capacityV);
        }
        $energy["capacity"] = $capacity;
        $battEff = dp2(floatval($_GET["battEff"]) / 100);
        $energy["battEff"] = $battEff;

    }





    //deal with any number of general outputs
    if (key_exists("oName", $_GET)) {
        $functions[] = "Discharge controller";
        $oNames = $_GET["oName"];
        for ($oIndex = 0; $oIndex < sizeof($oNames); $oIndex++) {
            $oName = $oNames[$oIndex];
            $oVoltage = inputVoltage($_GET["oVoltage"][$oIndex],0);
            $oFrequency = $_GET["oFrequency"][$oIndex];
            $oAW = $_GET["oAW"][$oIndex];
            $loadConns = $_GET["loadConns"][$oIndex];
            if ($loadConns  == -1) {
                $loadConns = "U";
            }
            $oUnits = $_GET["oUnits"][$oIndex];
            $oProtocolO = $_GET["oProtocolO"][$oIndex];
            $oProtocolR = $_GET["oProtocolR"][$oIndex];

            $oVoltage = ["offers" => $oVoltage ];

            if ($oFrequency == "") {
                $oFrequency = ["DC(0Hz)"];
            }
            $oFrequency = ["offers" => $oFrequency ];

            $port = array();
            $port["name"] = $oName;
            $port["function"] = ["offers" => "output"];
            $port["connections"] = ["offers" => intval($loadConns)];
            $port["voltage"] = $oVoltage;
            $port["ampsWatts"] = ["offers" => ["value" => floatval($oAW),"units" => $oUnits]];
            $port["frequency"] = $oFrequency;

            $port["protocol"] = ["offers" => $oProtocolO, "requires" => $oProtocolR];
            array_push($ports, $port);
        }

    }

    $data["functions"] = $functions;

    //system energy parameters

    $perHour = $_GET["perHour"];
    if ($perHour == "") {
        $perHour = 0;
    }
    $energy["dayHrs"] = 12;
    $energy["nightHrs"] = 12;
    $energy["perHour"] = floatval($perHour);
    $efficiency = $_GET["efficiency"];
    $energy["perDay"] = -dp2($perHour * 12);
    $energy["perNight"] = -dp2($perHour * 12);
    $energy["efficiency"] = dp2(floatval($efficiency)/100);




    $data["ports"] = $ports;

    $data["energy"] = $energy;




    $fileName = $_GET["fileName"].".json";

    $fileText = json_encode($data, JSON_PRETTY_PRINT);

//    echo ($fileText);

    $myfile = fopen("data/".$fileName,"w");
    fwrite($myfile,$fileText);
    fclose($myfile);



    echo ("<p>File $fileName successfully created</p>");



    ?>

    <form action="phpqrcode/p2.php" method="GET" name="inputData" id="inputData">
        <input type="hidden" id="file" name="file" value="<?=$fileName?>" />

        <input name="submit" type="submit" value="View the created JSON data..." />

    </form>


</body>
</html>
