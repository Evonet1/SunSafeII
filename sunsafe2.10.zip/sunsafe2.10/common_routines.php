<?php


    error_reporting(-1);
    ini_set("display_errors", 1);


function inputVoltage($asInput,$variation) {
    //From a value entered as a string, extract a range, or several ranges
    //Ranges selectable by the user or software are separated by commas - only one need be compatible
    //The upper and lower values within a range are separated by '-' - both must be compatible
    //If a single value is produced, a range +/-variation is given
    //Returned results: always an array of arrays of floating point values
    // 10 -> [[10.0]] or [[9.5,10.5]]
    // 9-11 -> [[9.0,11.0]]
    // 9,11 -> [[9.0],[11.0]]


    $selectableVolts = explode(",",$asInput);
    foreach ($selectableVolts as &$selected) {  //for all alternatives
        $range = explode('-',$selected);
        foreach ($range as &$minmax) {  //trap non-number, convert to float
            if (!is_numeric($minmax)) {
                die("illegal voltage format '$asInput' non-numeric");
            }
            $minmax = floatval($minmax);
        }
//        unset($minmax);
        switch (sizeof($range)) {
            case 1:
                $single = $range[0];
                $min = dp2($single * (1-$variation/100));
                $max = dp2($single * (1+$variation/100));
                $selected = [$min, $max];
                break;
            case 2:
                if ($range[0] > $range[1]) {
                    die("illegal voltage format '$asInput' (max&lt;min)");
                }
                $selected = $range;
                break;
            default:
                die("illegal voltage format '$asInput'");
        }

    }
//    unset($selected);
    return($selectableVolts);

}

function checkVoltage(&$offers,&$requires) {
    //Check two voltage ranges.  Return true or false.
    //Both offers and requires will be arrays of arrays.
    //The outside array lists alternative ranges, any one of which will be acceptable
    //The inner array will contain two elements, being a range min-max
    //return true if the required range is wider than the offered range

    //@@@@ The warning messages need to reference the relevant product and port! @@@@

    foreach ($offers as &$offer) {
        $offer1 = makeARange($offer,true);
        foreach ($requires as &$require) {
            if (($offer1[0] >= $require[0]) and ($offer1[1] <= $require[1])) {
                if (sizeof($offers) > 1){
                    echo ("Warning: voltage " . $offer[0] . "-" . $offer[1] . " must be selected<br/>");
                    $offers[$offer];
                }
                if (sizeof($requires) > 1) {
                    echo ("Warning: voltage " . $require[0] . "-" . $require[1] . " must be selected<br/>");
                    $requires = [$require];
                }
                unset($offer);
                unset($require);
                return(true);
            }
        }
        unset($require); // see https://stackoverflow.com/questions/15024616/php-foreach-change-original-array-values
    }
    unset($offer);
    return(false);
}

function makeARange($data,$mustBeARange) {
    //Ensure that data is an array with 1 or 2 elements min-max
    $data1 = $data;
    if (!is_array($data1))  {
        $data1 = [$data1];
    }
    switch (sizeof($data1)) {
        case 1:
            if ($mustBeARange){
                $single = $data1[0];
                if (!is_numeric($single)) {
                    die("illegal voltage format '$data' non-numeric");
                }
                $single = floatval($single);
                $min = $single * 0.95;
                $max = $single * 1.05;
                $result = [$min, $max];
            } else {
                $result = [$data1[0]];
            }
            break;
        case 2:
            if ($data1[0] > $data1[1]) {
                die("illegal voltage format '$data' (max&lt;min)");
            }
            $selected = $data1;
            break;
        default:
            die("illegal voltage format '$data'");
    }
    return ($result);
}



function dp2($number) {
    //reduce a floating point number to 2dp, but keep as a number
    $float = round($number * 100);
    return ($float / 100);
}



function array_prepend($array,$value)  {
    //prepend a value to an array, return the result
    $temp = array_reverse($array);
    array_push($temp, $value);
    return(array_reverse($temp));
}

function getOptions($optionList) {
    //Take an input which may be a number, or several separated by commas
    //Turn them into a floating point array
    $options = explode(',', $optionList);
    $out = array_map('floatval', $options);
    return ($out);
}


function genOptions($key) {
    //generate options for an HTML drop-down list, based on dict.csv.
    //The first entry will be the default.
    //can't use datalist allowing user entry because it doesn't support multiple selections
    global $dict;
    $first = true;
    foreach ($dict as $dict_entry) {
        if (substr($dict_entry[0], 0, 1) == $key) { //relevant dictionary entries
            echo ("<option");
            if ($first) {
                $first = false;
                echo (" selected");
            }
            echo (">" . $dict_entry[1] . "</option>" . PHP_EOL);
        }
    }
}

function checkKey($parameter) {
    //Look for a parameter in a URL, if found, return it, else return blank
    if (key_exists($parameter,$_GET)) {
        return ($_GET[$parameter]);
    } else {
        return ("");
    }
}

function tf($val)  {    //Print True or False
    if ($val) {
        echo ("True<br/>");
    } else {
        echo ("False<br/>");
    }
    return;
}


?>
