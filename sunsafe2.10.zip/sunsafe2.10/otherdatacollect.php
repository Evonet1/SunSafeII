
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/1999/REC-html401-19991224/loose.dtd">
<html xmlns:syd="urn:schemas-evonet-com" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <!-- Chris Moller, Evonet Energy, 2023-07-19    chris.moller@evonet.com -->
	<title>Sunsafe Infrastructure Data Capture</title>
	<!-- This will be accessed at http://www3.evonet1.com/sunsafe2.10/otherdatacollect.php       -->
	<meta charset="utf-8">

    <link href="dual-listbox.css" rel="stylesheet">


    <style type="text/css">
		SPAN.hidden {
			display: none;
		}
        body {
            background-color: lightblue;
        }
        h1 {
            text-align: center;
        }
        table.outside, th, td {
            border: 0px;
            margin: 25px;
        }
        /* Outside frame for ratings plate, connector etc*/
        table.frame, th, td {
            border: 1px solid black;
            background-color: lightblue;
        }
        /* Inner table for values */
        table.form, th, td {
            border: 0px;
        }


    </style>

	
</head>

<body >

    <h1>Sunsafe 2.10 Component data capture</h1>
    
    <?php

    error_reporting(-1);
    ini_set("display_errors",1);


    require_once("json_utilities.php");
    require_once("common_routines.php");



    $dict = load_dict();


    //populate appliances list
    echo ('<datalist id="appliances">' . PHP_EOL);
    genOptions("@");
    echo ('</datalist>' . PHP_EOL);

    //populate appliances list
    echo ('<datalist id="infrastructure">' . PHP_EOL);
    genOptions("?");
    echo ('</datalist>' . PHP_EOL);

    //populate protocols list
    echo ('<datalist id="protocols">' . PHP_EOL);
    genOptions("^");
    echo ('</datalist>' . PHP_EOL);

    //index.html is expected to deliver:
    //boolean values for solarPanel, solarIn, charger and battery
    //numerical values for the number of input and output ports


    //fetch the functional options from the start page    
    $solarPanel = (key_exists("solarPanel", $_GET));
    $solarIn = (key_exists("solarIn", $_GET));
    $charger = (key_exists("charger", $_GET));
    $battery = (key_exists("battery", $_GET));
    $inputs = $_GET["inputs"];
    $outputs = $_GET["outputs"];

    //identify various pathological input conditions
    if ((sizeof($_GET) == 3) and ($inputs + $outputs == 0)){ //inputs,outputs,submit
        echo ("The specified kit is empty!");
        exit(1);
    }

    if ($solarPanel and !$solarIn) {
        echo ("A solar panel can only connect to a solar input!");
        exit(1);
    }

    if ($battery and !$charger) {
        echo ("A battery can only connect to a battery port!");
        exit(1);
    }    

    if (!$solarIn and ($inputs == 0)) {
        echo ("There is no power source!");
        exit(1);
    }    

    if (!$charger and ($outputs == 0)) {
        echo ("There is nowhere for the power to go!");
        exit(1);
    }    

    ?>
      
 
    <datalist id="outputPorts">
        <option>DC output</option>
        <option>Mains output</option>
        <option>USB Phone charger</option>
    </datalist>

 



    <form action="other2json.php" method="GET" name="inputData" id="inputData">

        <table align="center">

            <tr>
                <td colspan="2" align="center">
                    <b>General</b>
                </td>
            </tr>
            <tr>
                <td align="right">Product and model: </td>
                <td><input type="text" id="product" name="product" value="" /></td>
            </tr>
            <tr>
                <td align="right">Description: </td>
                <td><input type="text" id="description" name="description" list="infrastructure" /></td>
            </tr>
        <?php
        if ($solarPanel) {
        ?>
            <tr>
                <td colspan="2" align="center">
                    <b>Solar Panel</b>
                </td>
            </tr>
            <tr>
                <td align="right">Rated peak power (Wp):</td><td>
                    <input id="wpk" name="wpk" value="0" />
                </td><td>Watts</td>
            </tr>

        <?php
        }

        if (!$solarPanel and $solarIn) {
            //If the solar panel and solarIn are not both part of a kit (and therefore presumably matched), we will need the electrical limitations of the controller's solar input
        ?>

            <tr>
                <td colspan="2" align="center">
                    <b>Solar Input</b>
                </td>
            </tr>
            <tr>
                <td align="right">Maximum permitted solar panel open-circuit voltage</td><td>
                    <input id="ocv" name="ocv" value="0" />
                </td><td>Volts</td>
            </tr>
            <tr>
                <td align="right">Maximum permitted solar panel short-circuit current</td><td>
                    <input id="scc" name="scc" value="0" />
                </td><td>Amps</td>
            </tr>
            <tr>
                <td align="right">Max number of solar panels connected in parallel to this port</td><td>
                    <input type="number" id="maxConns" name="maxConns" value="1" />
                </td><td>(-1 = unlimited)</td>
            </tr>
        <?php
        }        


        for ($inputCount = 0; $inputCount < $inputs; $inputCount++) {

        ?>

            <tr>
                <td colspan="2" align="center">
                    <b>General input <?=$inputCount+1?></b>
                </td>
            </tr>
            <tr>
                <td align="right">Port Name:</td>
                <td><input id="iName[]" name="iName[]" value="Input_<?=$inputCount?>" />
                </td><td>&nbsp;</td>
            </tr>
            <tr>
                <td align="right">Supply voltage or voltage range:</td>
                <td><input id="iVoltage[]" name="iVoltage[]" value="" />
                </td><td>Volts*</td>
            </tr>
            <tr>
                <td align="right">Supply frequency:</td>
                <td><select  name="iFrequency[]" id="iFrequency[]">
                    <?php
                    genOptions("&");   
                    ?> 
                </select></td>                </td><td>&nbsp;</td>
            </tr>
            <tr>
                <td align="right">Rated current/power</td><td>
                    <input id="iAW[]" name="iAW[]" value="" />
                </td><td><select  name="iUnits[]" id="iUnits[]">
                        <option value="Amps" selected>Amps</option>
                        <option value="Watts">Watts</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td align="right">Offers supply protocol:</td>
                <td><input id="iProtocolO[]" name="iProtocolO[]" list="protocols"  />
                </td><td>&nbsp;</td>
            </tr>
            <tr>
                <td align="right">Requires supply protocol:</td>
                <td><input id="iProtocolR[]" name="iProtocolR[]" list="protocols"  />
                </td><td>&nbsp;</td>
            </tr>
        <?php

        }        


        if ($charger and !$battery) {   //If the charger does not have an integral battery, we will need the electrical characteristics of the charger's battery port
        
        ?>
        
            <tr>
                <td colspan="2" align="center">
                    <b>Battery port</b>
                </td>
            </tr>
            <tr>
                <td align="right">Supported nominal battery voltage(s):</td>
                <td><input id="battV" name="battV" value="12" />
                </td><td>Volts*</td>
            </tr>
            <tr>
                <td align="right">Max number of identical batteries connected in parallel to this port</td><td>
                    <input type="number" id="battConns" name="battConns" value="1" />
                </td><td>(-1 = unlimited)</td>
            </tr>            <tr>
                <td align="right">Supported chemistries</td><td>
                <select  name="ctlChem[]" id="ctlChem[]" multiple >
                <?php
                genOptions("%");    //can't use datalist allowing user entry because it doesn't support multiple selections
                ?> 
                </select></td>
            </tr>
            <tr>
                <td colspan="2" align="center">
                    <em>(use Ctrl  to select multiple chemistries)</em>
                </td>
            </tr>
        <?php
        }
        if ($battery) {
    
        ?>
            <tr>
                <td colspan="2" align="center">
                    <b>Battery storage</b>
                </td>
            </tr>
            <tr>
                <td align="right">Battery energy storage capacity:</td>
                <td><input id="capacity" name="capacity" value="" /></td>
                <td>Watt-hours</td>            
            </tr>
            <tr>
                <td align="right">or:</td>
                <td><input id="capacityA" size="4" name="capacityA" value="" />Amp-hours @</td>
                <td><input id="capacityV" size="4" name="capacityV" value="" />Volts</td>
            </tr>            
            <tr>
                <td align="right">Battery round-trip efficiency:</td>
                <td><input id="battEff" name="battEff" value="85" /></td>
                <td>%</td>            
            </tr>            

        <?php

        }

        for ($outputCount = 0; $outputCount < $outputs; $outputCount++) {

        ?>

            <tr>
                <td colspan="2" align="center">
                    <b>General output <?=$outputCount+1?></b>
                </td>
            </tr>
            <tr>
                <td align="right">Port Name:</td>
                <td><input id="oName[]" name="oName[]" list="outputPorts" />
                    <input type="hidden" name="oType[]" id="oType[]" value="output" />
                </td><td>&nbsp;</td>
            </tr>
            <tr>
                <td align="right">Output voltage:</td>
                <td><input id="oVoltage[]" name="oVoltage[]" value="" />
                </td><td>Volts</td>
            </tr>            <tr>
                <td align="right">Output frequency:</td>
                <td><select  name="oFrequency[]" id="oFrequency[]">
                    <?php
                    genOptions("&");   
                    ?> 
                </select></td>
                </td><td>&nbsp;</td>
            </tr>
            <tr>
                <td align="right">Rated current/power</td><td>
                    <input id="oAW[]" name="oAW[]" value="" />
                </td><td><select  name="oUnits[]" id="oUnits[]">
                        <option value="Amps" selected>Amps</option>
                        <option value="Watts">Watts</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td align="right">Offers protocol:</td>
                <td><input id="oProtocolO[]" name="oProtocolO[]" list="protocols" />
                </td><td>&nbsp;</td>
            </tr>
            <tr>
                <td align="right">Requires protocol:</td>
                <td><input id="oProtocolR[]" name="oProtocolR[]" list="protocols" />
                </td><td>&nbsp;</td>
            </tr>            <tr>
                <td align="right">Max number of loads connected in parallel to this port</td><td>
                    <input type="number" id="loadConns[]" name="loadConns[]" value="1" />
                </td><td>(-1 = unlimited)</td>
            </tr>        <?php
        }
        ?>
             <tr>
                <td colspan="2" align="center">
                    <b>Energy efficiency</b>
                </td>
            </tr>
            <tr>
                <td align="right">No-load power consumption of this equipment:</td>
                <td><input id="perHour" name="perHour" value="0" /></td>
                <td>Watts</td>            
            </tr>
            <tr>
                <td align="right">Throughput energy efficiency:</td>
                <td><input id="efficiency" name="efficiency" value="95" /></td>
                <td>%</td>            
            </tr>
            <tr>
                <td colspan="2" align="center">
                    <b>Save</b>
                </td>
            </tr>       <tr>
                <td align="right">Product data file name</td><td>
                    <input id="fileName" name="fileName" value="" />
                </td><td>.json</td>
            </tr>   

        </table>


        <p  align="center"><input name="submit" type="submit" value="Create JSON file..." /></p>




    </form>
    <p  align="center">* For these parameters, a voltage range or alternative input frequencies may be entered, separated by commas</p>







</body>
</html>

